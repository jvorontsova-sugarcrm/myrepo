<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');


/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Master Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/master-subscription-agreement
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2012 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/

	

$mod_strings = array (
  'LBL_CONSKEY' => 'Cheia OAuth Consum',
  'LBL_CONSSECRET' => 'Cheia OAuth Consum Secret',
  'LBL_ASSIGNED_TO_ID' => 'Atribuit ID Utilizator',
  'LBL_ASSIGNED_TO_NAME' => 'Utilizator',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Data creearii:',
  'LBL_DATE_MODIFIED' => 'Data Modificarii:',
  'LBL_MODIFIED' => 'Modificat de:',
  'LBL_MODIFIED_ID' => 'Modificata de ID',
  'LBL_MODIFIED_NAME' => 'Modificata de Nume',
  'LBL_CREATED' => 'Creeata de',
  'LBL_CREATED_ID' => 'Creeata de ID',
  'LBL_DESCRIPTION' => 'Descriere',
  'LBL_DELETED' => 'Sters',
  'LBL_NAME' => 'Nume echipa',
  'LBL_CREATED_USER' => 'Creeata de Utilizator',
  'LBL_MODIFIED_USER' => 'Modificata de Utilizator',
  'LBL_LIST_NAME' => 'Nume',
  'LBL_LIST_FORM_TITLE' => 'Liste tinte',
  'LBL_MODULE_NAME' => 'Liste tinte',
  'LBL_MODULE_TITLE' => 'Note: Acasa',
  'LNK_NEW_RECORD' => 'Creeaza Conturi externe',
  'LNK_LIST' => 'Notificari',
  'LBL_TOKENS' => 'Jetoane',
);

