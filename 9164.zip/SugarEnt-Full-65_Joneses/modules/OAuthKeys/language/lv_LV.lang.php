<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');


/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Master Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/master-subscription-agreement
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2012 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/

	

$mod_strings = array (
  'LBL_ASSIGNED_TO_ID' => 'Piešķirts lietotājam ar ID',
  'LBL_ASSIGNED_TO_NAME' => 'Lietotājs',
  'LBL_CONSKEY' => 'Patērētāja atslēga',
  'LBL_CONSSECRET' => 'Patērētāja slepenā atslēga',
  'LBL_CREATED' => 'Izveidoja',
  'LBL_CREATED_ID' => 'Izveidotāja ID',
  'LBL_CREATED_USER' => 'Izveidoja',
  'LBL_DATE_ENTERED' => 'Izveidots',
  'LBL_DATE_MODIFIED' => 'Modificēts',
  'LBL_DELETED' => 'Dzēsts',
  'LBL_DESCRIPTION' => 'Apraksts',
  'LBL_ID' => 'ID',
  'LBL_LIST_FORM_TITLE' => 'OAuth atslēgas',
  'LBL_LIST_NAME' => 'Atslēgas nosaukums',
  'LBL_MODIFIED' => 'Modificēja',
  'LBL_MODIFIED_ID' => 'Modificētāja ID',
  'LBL_MODIFIED_NAME' => 'Modificēja',
  'LBL_MODIFIED_USER' => 'Modificēja',
  'LBL_MODULE_NAME' => 'OAuth atslēgas',
  'LBL_MODULE_TITLE' => 'OAuth atslēgas',
  'LBL_NAME' => 'Patērētāja atslēgas nosaukums',
  'LBL_TOKENS' => 'Tokens',
  'LNK_LIST' => 'Aplūkot OAuth atslēgas',
  'LNK_NEW_RECORD' => 'Izveidot OAuth atslēgu',
);

