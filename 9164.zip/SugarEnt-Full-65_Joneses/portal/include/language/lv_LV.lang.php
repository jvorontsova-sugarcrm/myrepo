<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');


/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Master Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/master-subscription-agreement
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2012 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/

	

$app_list_strings = array (
  'account_type_dom' => 
  array (
    '' => '',
    'Analyst' => 'Konsultants',
    'Competitor' => 'Konkurents',
    'Customer' => 'Klients',
    'Integrator' => 'Integrators',
    'Investor' => 'Investors',
    'Other' => 'Cits',
    'Partner' => 'Partneris',
    'Press' => 'Prese',
    'Prospect' => 'Potenciāls klients',
    'Reseller' => 'Izplatītājs',
  ),
  'activity_dom' => 
  array (
    'Call' => 'Zvans',
    'Email' => 'E-pasts',
    'Meeting' => 'Tikšanas',
    'Note' => 'Piezīme',
    'Task' => 'Uzdevums',
  ),
  'bopselect_type_dom' => 
  array (
    'Equals' => 'Vienāds ar',
  ),
  'bselect_type_dom' => 
  array (
    'bool_false' => 'Nē',
    'bool_true' => 'Jā',
  ),
  'bug_priority_dom' => 
  array (
    'High' => 'Augsta',
    'Low' => 'Zema',
    'Medium' => 'Vidēja',
    'Urgent' => 'Steidzama',
  ),
  'bug_resolution_dom' => 
  array (
    '' => '',
    'Accepted' => 'Apstiprināts',
    'Duplicate' => 'Dublikāts',
    'Fixed' => 'Izlabots',
    'Invalid' => 'Nederīgs',
    'Later' => 'Atliekams',
    'Out of Date' => 'Novecojis',
  ),
  'bug_status_dom' => 
  array (
    'Assigned' => 'Piešķirts',
    'Closed' => 'Aizvērts',
    'New' => 'Jauns',
    'Pending' => 'Gaidošs',
    'Rejected' => 'Noraidīts',
  ),
  'bug_type_dom' => 
  array (
    'Defect' => 'Defekts',
    'Feature' => 'Īpašība',
  ),
  'call_direction_dom' => 
  array (
    'Inbound' => 'Ienākošs',
    'Outbound' => 'Izejošs',
  ),
  'call_status_dom' => 
  array (
    'Held' => 'Noticis',
    'Not Held' => 'Nav noticis',
    'Planned' => 'Ieplānots',
  ),
  'campaign_status_dom' => 
  array (
    '' => '',
    'Active' => 'Aktīvs',
    'Complete' => 'Pabeigts',
    'In Queue' => 'Rindā',
    'Inactive' => 'Neaktīvs',
    'Planning' => 'Plānošanā',
    'Sending' => 'Izsūtīšanā',
  ),
  'campaign_type_dom' => 
  array (
    '' => '',
    'Email' => 'E-pasts',
    'Mail' => 'Pasts',
    'Print' => 'Izdrukas',
    'Radio' => 'Radio',
    'Telesales' => 'Pārdošana pa telefonu',
    'Television' => 'Televīzija',
    'Web' => 'Tīmeklis',
  ),
  'campainglog_activity_type_dom' => 
  array (
    '' => '',
    'contact' => 'Kontaktpersonas izveidotas',
    'invalid email' => 'Noraidītie ziņojumi, nederīga e-pasta adrese',
    'lead' => 'Interesenti izveidoti',
    'link' => 'Click-thru saite',
    'removed' => 'Izslēgts no lietošanas',
    'send error' => 'Noraidītie ziņojumi, cits',
    'targeted' => 'Ziņa nosūtīta/mēģināta nosūtīt',
    'viewed' => 'Apskatīta ziņa',
  ),
  'campainglog_target_type_dom' => 
  array (
    'Contacts' => 'Kontakti',
    'Leads' => 'Interesenti',
    'Prospects' => 'Mērķi',
    'Users' => 'Lietotāji',
  ),
  'case_priority_dom' => 
  array (
    'P1' => 'Augsta',
    'P2' => 'Vidēja',
    'P3' => 'Zema',
  ),
  'case_relationship_type_dom' => 
  array (
    '' => '',
    'Alternate Contact' => 'Alternatīvā kontaktpersona',
    'Primary Contact' => 'Primārā kontaktpersona',
  ),
  'case_status_dom' => 
  array (
    'Assigned' => 'Piešķirts',
    'Closed' => 'Aizvērts',
    'Duplicate' => 'Dublikāts',
    'New' => 'Jauns',
    'Pending Input' => 'Gaida informāciju',
    'Rejected' => 'Noraidīts',
  ),
  'checkbox_dom' => 
  array (
    '' => '',
    1 => 'Jā',
    2 => 'Nē',
  ),
  'contract_expiration_notice_dom' => 
  array (
    1 => '1 diena',
    3 => '3 dienas',
    5 => '5 dienas',
    7 => '1 nedēļa',
    14 => '2 nedēļas',
    21 => '3 nedēļas',
    31 => '1 mēnesis',
  ),
  'contract_payment_frequency_dom' => 
  array (
    'halfyearly' => 'Reizi pusgadā',
    'monthly' => 'Ikmēneša',
    'quarterly' => 'Reizi ceturksnī',
    'yearly' => 'Reizi gadā',
  ),
  'contract_status_dom' => 
  array (
    'inprogress' => 'Procesā',
    'notstarted' => 'Nav sākts',
    'signed' => 'Parakstīts',
  ),
  'cselect_type_dom' => 
  array (
    'Does not Equal' => 'Nav vienāds',
    'Equals' => 'Vienāds ar',
  ),
  'document_category_dom' => 
  array (
    '' => '',
    'Knowledege Base' => 'Zināšanu bāze',
    'Marketing' => 'Mārketings',
    'Sales' => 'Pārdošana',
  ),
  'document_status_dom' => 
  array (
    'Active' => 'Aktīvs',
    'Draft' => 'Sagatave',
    'Expired' => 'Beidzies',
    'FAQ' => 'BUJ',
    'Pending' => 'Gaidošs',
    'Under Review' => 'Caurskatē',
  ),
  'document_subcategory_dom' => 
  array (
    '' => '',
    'FAQ' => 'BUJ',
    'Marketing Collateral' => 'Mārketinga materiāli',
    'Product Brochures' => 'Produktu brošūras',
  ),
  'document_template_type_dom' => 
  array (
    '' => '',
    'eula' => 'EULA līgums',
    'license' => 'Licences līgums',
    'mailmerge' => 'Pasta sapludināšana',
    'nda' => 'NDA līgums',
  ),
  'dom_cal_month_long' => 
  array (
    1 => 'Janvāris',
    2 => 'Februāris',
    3 => 'Marts',
    4 => 'Aprīlis',
    5 => 'Maijs',
    6 => 'Jūnijs',
    7 => 'Jūlijs',
    8 => 'Augusts',
    9 => 'Septembris',
    10 => 'Oktobris',
    11 => 'Novembris',
    12 => 'Decembris',
  ),
  'dom_email_bool' => 
  array (
    'bool_false' => 'Nē',
    'bool_true' => 'Jā',
  ),
  'dom_email_distribution' => 
  array (
    '' => '--Nekāds--',
    'direct' => 'Tiešā piešķiršana',
    'leastBusy' => 'Mazāk aizņemtajiem',
    'roundRobin' => 'Viens-visiem',
  ),
  'dom_email_editor_option' => 
  array (
    '' => 'Noklusētais E-pasta formāts',
    'html' => 'HTML E-pasts',
    'plain' => 'Atklāta teksta E-pasts',
  ),
  'dom_email_errors' => 
  array (
    1 => 'Norādiet tikai  vienu lietotāju, kad tieši piešķiriet ierakstus',
    2 => 'Jums ir jāpiešķir tikai atzīmētie ieraksti, kad tieši piešķiriet ierakstus',
  ),
  'dom_email_link_type' => 
  array (
    '' => 'Noklusētais E-pasta klients',
    'mailto' => 'Ārējs E-pasta klients',
    'sugar' => 'SugarCRM E-pasta klients',
  ),
  'dom_email_server_type' => 
  array (
    '' => '--Neviens--',
    'imap' => 'IMAP',
    'pop3' => 'POP3',
  ),
  'dom_email_status' => 
  array (
    'archived' => 'Arhivēts',
    'closed' => 'Aizvērts',
    'draft' => 'Sagatavošanā',
    'read' => 'Izlasīts',
    'replied' => 'Atbildēts',
    'send_error' => 'Nosūtīšanas kļūda',
    'sent' => 'Nosūtīts',
    'unread' => 'Nelasīts',
  ),
  'dom_email_types' => 
  array (
    'archived' => 'Arhivēts',
    'draft' => 'Sagatavošanā',
    'inbound' => 'Ienākošs',
    'out' => 'Nosūtīts',
  ),
  'dom_int_bool' => 
  array (
    1 => 'Jā',
  ),
  'dom_mailbox_type' => 
  array (
    'bounce' => 'Noraidītiem ziņojumiem',
    'bug' => 'Izveidot kļūdu',
    'contact' => 'Izveidot kontaktu',
    'pick' => 'Izveidot [jebko]',
    'sales' => 'Izveidot interesentu',
    'support' => 'Izveidot pieteikumu',
    'task' => 'Izveidot uzdevumu',
  ),
  'dom_meeting_accept_options' => 
  array (
    'accept' => 'Apstiprināt',
    'decline' => 'Noraidīt',
    'tentative' => 'Nekonkrēti',
  ),
  'dom_meeting_accept_status' => 
  array (
    'accept' => 'Apstiprināts',
    'decline' => 'Noraidīts',
    'none' => 'Nav',
    'tentative' => 'Nekonkrēts',
  ),
  'dom_report_types' => 
  array (
    'detailed_summary' => 'Kopsummas ar detaļām',
    'summary' => 'Kopsummas',
    'tabular' => 'Rindas un kolonnas',
  ),
  'dom_switch_bool' => 
  array (
    '' => 'Nē',
    'off' => 'Nē',
    'on' => 'Jā',
  ),
  'dom_timezones' => 
  array (
    -12 => '(GMT - 12) International Date Line West',
    -11 => '(GMT - 11) Midway Island, Samoa',
    -10 => '(GMT - 10) Hawaii',
    -9 => '(GMT - 9) Alaska',
    -8 => '(GMT - 8) San Francisco',
    -7 => '(GMT - 7) Phoenix',
    -6 => '(GMT - 6) Saskatchewan',
    -5 => '(GMT - 5) New York',
    -4 => '(GMT - 4) Santiago',
    -3 => '(GMT - 3) Buenos Aires',
    -2 => '(GMT - 2) Mid-Atlantic',
    -1 => '(GMT - 1) Azores',
    1 => '(GMT + 1) Madrid',
    2 => '(GMT + 2) Athens',
    3 => '(GMT + 3) Moscow',
    4 => '(GMT + 4) Kabul',
    5 => '(GMT + 5) Ekaterinburg',
    6 => '(GMT + 6) Astana',
    7 => '(GMT + 7) Bangkok',
    8 => '(GMT + 8) Perth',
    9 => '(GMT + 9) Seol',
    10 => '(GMT + 10) Brisbane',
    11 => '(GMT + 11) Solomone Is.',
    12 => '(GMT + 12) Auckland',
  ),
  'dom_timezones_extra' => 
  array (
    -12 => '(GMT-12) International Date Line West',
    -11 => '(GMT-11) Midway Island, Samoa',
    -10 => '(GMT-10) Hawaii',
    -9 => '(GMT-9) Alaska',
    -8 => '(GMT-8) (PST)',
    -7 => '(GMT-7) (MST)',
    -6 => '(GMT-6) (CST)',
    -5 => '(GMT-5) (EST)',
    -4 => '(GMT-4) Santiago',
    -3 => '(GMT-3) Buenos Aires',
    -2 => '(GMT-2) Mid-Atlantic',
    -1 => '(GMT-1) Azores',
    1 => '(GMT+1) Madrid',
    2 => '(GMT+2) Athens',
    3 => '(GMT+3) Moscow',
    4 => '(GMT+4) Kabul',
    5 => '(GMT+5) Ekaterinburg',
    6 => '(GMT+6) Astana',
    7 => '(GMT+7) Bangkok',
    8 => '(GMT+8) Perth',
    9 => '(GMT+9) Seol',
    10 => '(GMT+10) Brisbane',
    11 => '(GMT+11) Solomone Is.',
    12 => '(GMT+12) Auckland',
  ),
  'dselect_type_dom' => 
  array (
    'Does not Equal' => 'Nav vienāds',
    'Equals' => 'Vienāds ar',
    'Less Than' => 'Mazāk par',
    'More Than' => 'Vairāk par',
  ),
  'dtselect_type_dom' => 
  array (
    'Less Than' => 'ir mazāk par',
    'More Than' => 'bija vairāk kā',
  ),
  'duration_intervals' => 
  array (
    15 => '15',
    30 => '30',
    45 => '45',
  ),
  'email_marketing_status_dom' => 
  array (
    '' => '',
    'active' => 'Aktīvs',
    'inactive' => 'Neaktīvs',
  ),
  'employee_status_dom' => 
  array (
    'Active' => 'Aktīvs',
    'Leave of Absence' => 'Atvaļinājumā',
    'Terminated' => 'Atlaists',
  ),
  'forecast_schedule_status_dom' => 
  array (
    'Active' => 'Aktīvs',
    'Inactive' => 'Neaktīvs',
  ),
  'forecast_type_dom' => 
  array (
    'Direct' => 'Tiešs',
    'Rollup' => 'Apkopots',
  ),
  'industry_dom' => 
  array (
    '' => '',
    'Apparel' => 'Apģērbi',
    'Banking' => 'Banku pakalpojumi',
    'Biotechnology' => 'Biotehnoloģija',
    'Chemicals' => 'Ķīmiskā rūpniecība',
    'Communications' => 'Komunikācijas',
    'Construction' => 'Celtniecība',
    'Consulting' => 'Konsultācijas',
    'Education' => 'Izglītība',
    'Electronics' => 'Elektronika',
    'Energy' => 'Enerģētika',
    'Engineering' => 'Inženierzinātnes',
    'Entertainment' => 'Izklaide',
    'Environmental' => 'Vides aizsardzība',
    'Finance' => 'Finansu pakalpojumi',
    'Government' => 'Valstiska organizācija',
    'Healthcare' => 'Veselības aprūpe',
    'Hospitality' => 'Izmitināšana',
    'Insurance' => 'Apdrošināšana',
    'Machinery' => 'Mašīnbūve',
    'Manufacturing' => 'Ražošana',
    'Media' => 'Mēdiji',
    'Not For Profit' => 'Bezpeļņas organizācija',
    'Other' => 'Cits',
    'Recreation' => 'Rehabilitācija',
    'Retail' => 'Mazumtirdzniecība',
    'Shipping' => 'Piegādes pakalpojumi',
    'Technology' => 'Tehnoloģijas',
    'Telecommunications' => 'Telekomunikācijas',
    'Transportation' => 'Transporta pakalpojumi',
    'Utilities' => 'Komunālie pakalpojumi',
  ),
  'language_pack_name' => 'US English',
  'layouts_dom' => 
  array (
    'Invoice' => 'Rēķins',
    'Standard' => 'Piedāvājums',
    'Terms' => 'Apmaksas noteikumi',
  ),
  'lead_source_dom' => 
  array (
    '' => '',
    'Cold Call' => 'Darījuma zvans',
    'Conference' => 'Konference',
    'Direct Mail' => 'Tiešais pasts',
    'Email' => 'E-pasts',
    'Employee' => 'Darbinieks',
    'Existing Customer' => 'Esošs klients',
    'Other' => 'Cits',
    'Partner' => 'Partneris',
    'Public Relations' => 'Sabiedriskās attiecības',
    'Self Generated' => 'Pašģenerēts',
    'Trade Show' => 'Nozares izstāde',
    'Web Site' => 'Mājas lapa',
    'Word of mouth' => 'Privāta saziņa',
  ),
  'lead_status_dom' => 
  array (
    '' => '',
    'Assigned' => 'Piešķirts',
    'Converted' => 'Konvertēts',
    'Dead' => 'Beigts',
    'In Process' => 'Procesā',
    'New' => 'Jauns',
    'Recycled' => 'Izmests',
  ),
  'lead_status_noblank_dom' => 
  array (
    'Assigned' => 'Piešķirts',
    'Converted' => 'Konvertēts',
    'Dead' => 'Izbeigts',
    'In Process' => 'Procesā',
    'New' => 'Jauns',
    'Recycled' => 'Izmests',
  ),
  'meeting_status_dom' => 
  array (
    'Held' => 'Noticis',
    'Not Held' => 'Nav noticis',
    'Planned' => 'Ieplānots',
  ),
  'messenger_type_dom' => 
  array (
    '' => '',
    'AOL' => 'AOL',
    'MSN' => 'MSN',
    'Yahoo!' => 'Yahoo!',
  ),
  'moduleList' => 
  array (
    'Bugs' => 'Kļūdas',
    'Cases' => 'Pieteikumi',
    'FAQ' => 'BUJ',
    'Home' => 'Sākums',
    'KBDocuments' => 'Zināšanu bāze',
    'Newsletters' => 'Biļeteni',
    'Notes' => 'Piezīmes',
    'Teams' => 'Darba grupas',
    'Users' => 'Lietotāji',
  ),
  'moduleListSingular' => 
  array (
    'Bugs' => 'Kļūda',
    'Cases' => 'Pieteikums',
    'Home' => 'Sākums',
    'Notes' => 'Piezīme',
    'Teams' => 'Darba grupa',
    'Users' => 'Lietotājs',
  ),
  'mselect_type_dom' => 
  array (
    'Equals' => 'vienāds ar',
    'in' => 'viens no',
  ),
  'notifymail_sendtype' => 
  array (
    'SMTP' => 'SMTP',
  ),
  'opportunity_relationship_type_dom' => 
  array (
    '' => '',
    'Business Decision Maker' => 'Biznesa lēmumu pieņēmējs',
    'Business Evaluator' => 'Biznesa vērtētājs',
    'Executive Sponsor' => 'Vadošais sponsors',
    'Influencer' => 'Ietekmētājs',
    'Other' => 'Cits',
    'Primary Decision Maker' => 'Primārais lēmumu pieņēmējs',
    'Technical Decision Maker' => 'Tehniskais lēmumu pieņēmējs',
    'Technical Evaluator' => 'Tehniskais vērtētājs',
  ),
  'opportunity_type_dom' => 
  array (
    '' => '',
    'Existing Business' => 'Esošs uzņēmums',
    'New Business' => 'Jauns uzņēmums',
  ),
  'order_stage_dom' => 
  array (
    'Cancelled' => 'Atcelts',
    'Confirmed' => 'Apstiprināts',
    'On Hold' => 'Apturēts',
    'Pending' => 'Gaidošs',
    'Shipped' => 'Piegādāts',
  ),
  'payment_terms' => 
  array (
    '' => '',
    'Net 15' => '15 dienas',
    'Net 30' => '30 dienas',
  ),
  'pricing_formula_dom' => 
  array (
    'Fixed' => 'Fiksēta cena',
    'IsList' => 'Kataloga cena',
    'PercentageDiscount' => 'Atlaide no kataloga cenas',
    'PercentageMarkup' => 'Uzcenojums pašizmaksai',
    'ProfitMargin' => 'Peļņas daļa',
  ),
  'product_category_dom' => 
  array (
    '' => '',
    'Accounts' => 'Uzņēmumi',
    'Activities' => 'Darbības',
    'Bug Tracker' => 'Kļūdas',
    'Calendar' => 'Kalendārs',
    'Calls' => 'Zvani',
    'Campaigns' => 'Kampaņas',
    'Cases' => 'Pieteikumi',
    'Contacts' => 'Kontakti',
    'Currencies' => 'Valūtas',
    'Dashboard' => 'Darba vieta',
    'Documents' => 'Dokumenti',
    'Emails' => 'E-pasti',
    'Feeds' => 'Barotnes',
    'Forecasts' => 'Prognozes',
    'Help' => 'Palīdzība',
    'Home' => 'Sākums',
    'Leads' => 'Interesenti',
    'Meetings' => 'Tikšanās',
    'Notes' => 'Piezīmes',
    'Opportunities' => 'Iespējas',
    'Outlook Plugin' => 'Outlook spraudnis',
    'Product Catalog' => 'Produktu katalogs',
    'Products' => 'Produkti',
    'Projects' => 'Projekti',
    'Quotes' => 'Piedāvājumi',
    'RSS' => 'RSS',
    'Releases' => 'Laidieni',
    'Studio' => 'Studio',
    'Upgrade' => 'Jaunināšana',
    'Users' => 'Lietotāji',
  ),
  'product_status_dom' => 
  array (
    'Orders' => 'Pasūtīts',
    'Quotes' => 'Piedāvāts',
    'Ship' => 'Piegādāts',
  ),
  'product_status_quote_key' => 'Piedāvājumi',
  'product_template_status_dom' => 
  array (
    'Available' => 'Ir noliktāvā',
    'Unavailable' => 'Nav pieejams',
  ),
  'project_task_priority_options' => 
  array (
    'High' => 'Augsta',
    'Low' => 'Zema',
    'Medium' => 'Vidēja',
  ),
  'project_task_status_options' => 
  array (
    'Completed' => 'Pabeigts',
    'Deferred' => 'Atlikts',
    'In Progress' => 'Procesā',
    'Not Started' => 'Nav sākts',
    'Pending Input' => 'Gaida informāciju',
  ),
  'project_task_utilization_options' => 
  array (
    25 => '25',
    50 => '50',
    75 => '75',
    100 => '100',
  ),
  'prospect_list_type_dom' => 
  array (
    'default' => 'Noklusēts',
    'exempt' => 'Noklusētais saraksts pēc ID',
    'exempt_address' => 'Noklusētais saraksts pēc e-pasta adreses',
    'exempt_domain' => 'Noklusētais saraksts pēc domēna',
    'seed' => 'Seed',
    'test' => 'Test',
  ),
  'query_calc_oper_dom' => 
  array (
    '*' => '(X) Reizināt ar',
    '+' => '(+) Plus',
    '-' => '(-) Mīnuss',
    '/' => '(/) Dalīt ar',
  ),
  'quote_relationship_type_dom' => 
  array (
    '' => '',
    'Business Decision Maker' => 'Biznesa lēmumu pieņēmējs',
    'Business Evaluator' => 'Biznesa vērtētājs',
    'Executive Sponsor' => 'Vadošais sponsors',
    'Influencer' => 'Ietekmētājs',
    'Other' => 'Cits',
    'Primary Decision Maker' => 'Primārais lēmumu pieņēmējs',
    'Technical Decision Maker' => 'Tehniskais lēmumu pieņēmējs',
    'Technical Evaluator' => 'Tehniskais vērtētājs',
  ),
  'quote_stage_dom' => 
  array (
    'Closed Accepted' => 'Aizvērts - akceptēts',
    'Closed Dead' => 'Aizvērts - bezcerīgs',
    'Closed Lost' => 'Aizvērts - zaudēts',
    'Confirmed' => 'Apstiprināts',
    'Delivered' => 'Piegādāts',
    'Draft' => 'Sagatave',
    'Negotiation' => 'Pārrunu procesā',
    'On Hold' => 'Apturēts',
  ),
  'quote_type_dom' => 
  array (
    'Orders' => 'Pasūtījums',
    'Quotes' => 'Piedāvājums',
  ),
  'record_type_display' => 
  array (
    'Accounts' => 'Uzņēmums',
    'Bugs' => 'Kļūda',
    'Cases' => 'Pieteikums',
    'Contacts' => 'Kontaktpersona',
    'Leads' => 'Interesents',
    'Opportunities' => 'Iespēja',
    'ProductTemplates' => 'Produkts',
    'Project' => 'Projekts',
    'ProjectTask' => 'Projekta uzdevums',
    'Quotes' => 'Piedāvājumi',
    'Tasks' => 'Uzdevums',
  ),
  'record_type_display_notes' => 
  array (
    'Accounts' => 'Uzņēmums',
    'Bugs' => 'Kļūda',
    'Calls' => 'Zvans',
    'Cases' => 'Pieteikums',
    'Contacts' => 'Kontaktpersona',
    'Contracts' => 'Līgums',
    'Emails' => 'E-pasts',
    'Leads' => 'Interesents',
    'Meetings' => 'Tikšanās',
    'Opportunities' => 'Iespēja',
    'ProductTemplates' => 'Produkts',
    'Products' => 'Produkts',
    'Project' => 'Projekts',
    'ProjectTask' => 'Projekta uzdevums',
    'Quotes' => 'Piedāvājums',
  ),
  'reminder_max_time' => '3600',
  'reminder_time_options' => 
  array (
    60 => '1 minūti pirms',
    300 => '5 minūtes pirms',
    600 => '10 minūtes pirms',
    900 => '15 minūtes pirms',
    1800 => '30 minūtes pirms',
    3600 => '1 stundu pirms',
  ),
  'sales_probability_dom' => 
  array (
    'Closed Lost' => '',
    'Closed Won' => '100',
    'Id. Decision Makers' => '40',
    'Needs Analysis' => '25',
    'Negotiation/Review' => '80',
    'Perception Analysis' => '50',
    'Proposal/Price Quote' => '65',
    'Prospecting' => '10',
    'Qualification' => '20',
    'Value Proposition' => '30',
  ),
  'sales_stage_dom' => 
  array (
    'Closed Lost' => 'Zaudēts',
    'Closed Won' => 'Iegūts',
    'Id. Decision Makers' => 'Lēmēju noteikšana',
    'Needs Analysis' => 'Prasību analīze',
    'Negotiation/Review' => 'Pārrunas',
    'Perception Analysis' => 'Analīze',
    'Proposal/Price Quote' => 'Piedāvājuma gatavošana',
    'Prospecting' => 'Iepazīšanās',
    'Qualification' => 'Kvalifikācija',
    'Value Proposition' => 'Vērtēšana',
  ),
  'salutation_dom' => 
  array (
    '' => '',
    'Dr.' => 'Dr.',
    'Mr.' => 'A. god.',
    'Mrs.' => 'Ļ. cien.',
    'Ms.' => 'Ļ. cien.',
    'Prof.' => 'Prof.',
  ),
  'schedulers_times_dom' => 
  array (
    'completed' => 'Pabeigts',
    'failed' => 'Neveiksmīgs',
    'in progress' => 'Procesā',
    'no curl' => 'Nav palaists: nav pieejama cURL',
    'not run' => 'Izpildes laiks pagājis, nav izpildīts',
    'ready' => 'Gatavs',
  ),
  'source_dom' => 
  array (
    '' => '',
    'Forum' => 'Forums',
    'InboundEmail' => 'E-pasts',
    'Internal' => 'Iekšējs',
    'Web' => 'Tīmeklis',
  ),
  'support_term_dom' => 
  array (
    '+1 year' => '1 gads',
    '+2 years' => '2 gadi',
    '+6 months' => '6 mēneši',
  ),
  'task_priority_dom' => 
  array (
    'High' => 'Augsta',
    'Low' => 'Zema',
    'Medium' => 'Vidēja',
  ),
  'task_status_dom' => 
  array (
    'Completed' => 'Pabeigts',
    'Deferred' => 'Atcelts',
    'In Progress' => 'Procesā',
    'Not Started' => 'Nav sākts',
    'Pending Input' => 'Gaida',
  ),
  'tax_class_dom' => 
  array (
    'Non-Taxable' => 'Bez nodokļiem',
    'Taxable' => 'Ar nodokļiem',
  ),
  'tselect_type_dom' => 
  array (
    14440 => '4 stundas',
    28800 => '8 stundas',
    43200 => '12 stundas',
    86400 => '1 diena',
    172800 => '2 dienas',
    259200 => '3 dienas',
    345600 => '4 dienas',
    432000 => '5 dienas',
    604800 => '1 nedēļa',
    1209600 => '2 nedēļas',
    1814400 => '3 nedēļas',
    2592000 => '30 dienas',
    5184000 => '60 dienas',
    7776000 => '90 dienas',
    10368000 => '120 dienas',
    12960000 => '150 dienas',
    15552000 => '180 dienas',
  ),
  'user_status_dom' => 
  array (
    'Active' => 'Aktīvs',
    'Inactive' => 'Neaktīvs',
  ),
  'wflow_action_datetime_type_dom' => 
  array (
    'Existing Value' => 'Esoša vērtība',
    'Triggered Date' => 'Trigerētais datums',
  ),
  'wflow_action_type_dom' => 
  array (
    'new' => 'Jauns ieraksts',
    'update' => 'Atjaunināt ierakstu',
    'update_rel' => 'Atjaunināt saistītos ierakstus',
  ),
  'wflow_address_type_dom' => 
  array (
    'bcc' => 'BCC:',
    'cc' => 'CC:',
    'to' => 'To:',
  ),
  'wflow_address_type_invite_dom' => 
  array (
    'bcc' => 'BCC:',
    'cc' => 'CC:',
    'invite_only' => '(tikai ar ielūgumiem)',
    'to' => 'To:',
  ),
  'wflow_address_type_to_only_dom' => 
  array (
    'to' => 'To:',
  ),
  'wflow_adv_enum_type_dom' => 
  array (
    'advance' => 'Pārvietot nolaižamo izvēlni uz priekšu par',
    'retreat' => 'Pārvietot nolaižamo izvēlni atpakaļ par',
  ),
  'wflow_adv_team_type_dom' => 
  array (
    'current_team' => 'Aktīvā lietotāja darba grupa',
    'team_id' => 'Ieraksta darba grupai',
  ),
  'wflow_adv_user_type_dom' => 
  array (
    'assigned_user_id' => 'Lietotājam, kam piešķirts ieraksts',
    'created_by' => 'Lietotājam, kas izveidoja ierakstu',
    'current_user' => 'Pašreizējais lietotājs',
    'modified_user_id' => 'Lietotājam, kas pēdējais modificēja',
  ),
  'wflow_alert_type_dom' => 
  array (
    'Email' => 'E-pasts',
    'Invite' => 'Uzaicinājums',
  ),
  'wflow_array_type_dom' => 
  array (
    'future' => 'Jaunā vērtība',
    'past' => 'Vecā vērtība',
  ),
  'wflow_fire_order_dom' => 
  array (
    'actions_alerts' => 'Darbība pēc tam brīdinājums',
    'alerts_actions' => 'Brīdinājums pēc tam darbība',
  ),
  'wflow_record_type_dom' => 
  array (
    'All' => 'Jaunie un atjauninātie ieraksti',
    'New' => 'Tikai jaunie ieraksti',
    'Update' => 'Tikai atjauninātos ierakstus',
  ),
  'wflow_rel_type_dom' => 
  array (
    'all' => 'Visi saistītie',
    'filter' => 'Filtrēti saistītie',
  ),
  'wflow_relate_type_dom' => 
  array (
    'Manager' => 'Lietotāju menedžeris',
    'Self' => 'Lietotājs',
  ),
  'wflow_relfilter_type_dom' => 
  array (
    'all' => 'visi saistītie',
    'any' => 'jebkuri saistītie',
  ),
  'wflow_set_type_dom' => 
  array (
    'Advanced' => 'Paplašinātās iespējas',
    'Basic' => 'Pamata iespējas',
  ),
  'wflow_source_type_dom' => 
  array (
    'Custom Template' => 'Pielāgota veidne',
    'Normal Message' => 'Parasts ziņojums',
    'System Default' => 'Sistēmas noklusējums',
  ),
  'wflow_type_dom' => 
  array (
    'Normal' => 'Kad ieraksts saglabāts',
    'Time' => 'Kad pagājis laiks',
  ),
  'wflow_user_type_dom' => 
  array (
    'current_user' => 'Lietotājs',
    'rel_user' => 'Saistītie lietotāji',
    'rel_user_custom' => 'Saistītais pielāgotais lietotājs',
    'specific_role' => 'Konkrēta loma',
    'specific_team' => 'Konkrēta darba grupa',
    'specific_user' => 'Konkrēts lietotājs',
  ),
);

$app_strings = array (
  'ERROR_FULLY_EXPIRED' => 'Jūsu uzņēmuma SugarCRM licence ir beigusies jau vairāk kā 30 dienas, un tā jāatjaunina. Tikai administrators tagad var pieslēgties sistēmai.',
  'ERROR_LICENSE_EXPIRED' => 'Jūsu uzņēmuma SugarCRM licence ir jāatjaunina. Tikai administrators tagad var pieslēgties sistēmai.',
  'ERROR_NO_RECORD' => 'Kļūda izgūstot ierakstu. Šis ieraksts ir dzēsts vai arī jums nav piekļuves tiesību.',
  'ERR_CREATING_FIELDS' => 'Kļūda aizpildot papildus informācijas laukus:',
  'ERR_CREATING_TABLE' => 'Kļūda veidojot tabulu:',
  'ERR_DELETE_RECORD' => 'Jānorāda ieraksta numurs, lai dzēstu kontaktpersonu.',
  'ERR_EXPORT_DISABLED' => 'Eksportēšana atspējota.',
  'ERR_EXPORT_TYPE' => 'Kļūda eksportējot',
  'ERR_INVALID_AMOUNT' => 'Ievadiet derīgu daudzumu',
  'ERR_INVALID_DATE' => 'Ievadiet derīgu datumu.',
  'ERR_INVALID_DATE_FORMAT' => 'Datuma formātam jābūt:',
  'ERR_INVALID_DAY' => 'Ievadiet pareizu dienu.',
  'ERR_INVALID_EMAIL_ADDRESS' => 'nederīga e-pasta adrese.',
  'ERR_INVALID_HOUR' => 'Ievadiet pareizu stundu.',
  'ERR_INVALID_MONTH' => 'Ievadiet derīgu mēnesi.',
  'ERR_INVALID_REQUIRED_FIELDS' => 'Nederīgs obligātais lauks:',
  'ERR_INVALID_TIME' => 'Ievadiet derīgu laiku.',
  'ERR_INVALID_VALUE' => 'Nederīga vērtība:',
  'ERR_INVALID_YEAR' => 'Ievadiet pareizu 4 ciparu gadu.',
  'ERR_MISSING_REQUIRED_FIELDS' => 'Trūkst obligātais lauks:',
  'ERR_NEED_ACTIVE_SESSION' => 'Lai eksportētu saturu, nepieciešama aktīva sesija.',
  'ERR_NOTHING_SELECTED' => 'Izvēlaties, lai turpinātu.',
  'ERR_OPPORTUNITY_NAME_DUPE' => 'Iespēja ar nosaukumu %s jau eksistē. Zemāk ievadiet citu nosaukumu.',
  'ERR_OPPORTUNITY_NAME_MISSING' => 'Iespējas nosaukums nav ievadīts. Zemāk ievadiet iespējas nosaukumu.',
  'ERR_PORTAL_LOGIN_FAILED' => 'Nevar izveidot portāla pieteikšanās sesiju. Sazinieties ar administratoru.',
  'ERR_RESOURCE_MANAGEMENT_INFO' => 'Atpakaļ uz  <a href="index.php">Sākums</a>',
  'ERR_SELF_REPORTING' => 'Lietotājs nevar atskaitīties pats sev.',
  'ERR_SQS_NO_MATCH' => 'Nav atbilstības',
  'ERR_SQS_NO_MATCH_FIELD' => 'Nav atbilstības laukā:',
  'LBL_ACCOUNT' => 'Uzņēmums',
  'LBL_ACCOUNTS' => 'Uzņēmumi',
  'LBL_ACCUMULATED_HISTORY_BUTTON_KEY' => 'H',
  'LBL_ACCUMULATED_HISTORY_BUTTON_LABEL' => 'Kopsavilkums',
  'LBL_ACCUMULATED_HISTORY_BUTTON_TITLE' => 'Kopsavilkums',
  'LBL_ADDITIONAL_DETAILS' => 'Papildus informācija',
  'LBL_ADDITIONAL_DETAILS_CLOSE' => 'Aizvērt',
  'LBL_ADDITIONAL_DETAILS_CLOSE_TITLE' => 'Klikšķiniet, lai aizvērtu',
  'LBL_ADD_BUTTON' => 'Pievienot',
  'LBL_ADD_BUTTON_KEY' => 'A',
  'LBL_ADD_BUTTON_TITLE' => 'Pievienot',
  'LBL_ADD_DOCUMENT' => 'Pievienot dokumentu',
  'LBL_ADD_TO_PROSPECT_LIST_BUTTON_KEY' => 'L',
  'LBL_ADD_TO_PROSPECT_LIST_BUTTON_LABEL' => 'Pievienot mērķu sarakstam',
  'LBL_ADD_TO_PROSPECT_LIST_BUTTON_TITLE' => 'Pievienot mērķu sarakstam',
  'LBL_ADMIN' => 'Administrators',
  'LBL_ALT_HOT_KEY' => '',
  'LBL_ARCHIVE' => 'Arhīvs',
  'LBL_ASSIGNED_TO' => 'Piešķirts lietotājam:',
  'LBL_ASSIGNED_TO_USER' => 'Piešķirts lietotājam',
  'LBL_BACK' => 'Atpakaļ',
  'LBL_BILL_TO_ACCOUNT' => 'Rēķins klientam',
  'LBL_BILL_TO_CONTACT' => 'Rēķins kontaktpersonai',
  'LBL_BROWSER_TITLE' => 'SugarCRM - komerciāls atvērtā koda CRM',
  'LBL_BUGS' => 'Kļūdas',
  'LBL_BY' => 'kas',
  'LBL_CALLS' => 'Zvani',
  'LBL_CAMPAIGNS_SEND_QUEUED' => 'Izsūtīt rindā esošos kampaņu E-pastus',
  'LBL_CANCEL_BUTTON_KEY' => 'X',
  'LBL_CANCEL_BUTTON_LABEL' => 'Atcelt',
  'LBL_CANCEL_BUTTON_TITLE' => 'Atcelt',
  'LBL_CASE' => 'Pieteikums:',
  'LBL_CASES' => 'Pieteikumi',
  'LBL_CHANGE_BUTTON_KEY' => 'G',
  'LBL_CHANGE_BUTTON_LABEL' => 'Mainīt',
  'LBL_CHANGE_BUTTON_TITLE' => 'Mainīt',
  'LBL_CHANGE_PASSWORD' => 'Mainīt paroli',
  'LBL_CHARSET' => 'UTF-8',
  'LBL_CHECKALL' => 'Atzīmēt visu',
  'LBL_CLEARALL' => 'Notīrīt visu',
  'LBL_CLEAR_BUTTON_KEY' => 'C',
  'LBL_CLEAR_BUTTON_LABEL' => 'Notīrīt',
  'LBL_CLEAR_BUTTON_TITLE' => 'Notīrīt',
  'LBL_CLOSEALL_BUTTON_KEY' => 'Q',
  'LBL_CLOSEALL_BUTTON_LABEL' => 'Aizvērt visu',
  'LBL_CLOSEALL_BUTTON_TITLE' => 'Aizvērt visu',
  'LBL_CLOSE_WINDOW' => 'Aizvērt logu',
  'LBL_COMPOSE_EMAIL_BUTTON_KEY' => 'L',
  'LBL_COMPOSE_EMAIL_BUTTON_LABEL' => 'Raksīt e-pastu',
  'LBL_COMPOSE_EMAIL_BUTTON_TITLE' => 'Rakstīt E-pastu',
  'LBL_CONTACT' => 'Kontaktpersona',
  'LBL_CONTACTS' => 'Kontaktpersonas',
  'LBL_CONTACT_LIST' => 'Kontaktpersonu saraksts',
  'LBL_CREATED' => 'Izveidoja',
  'LBL_CREATED_BY_USER' => 'Izveidoja lietotājs',
  'LBL_CREATE_BUTTON_LABEL' => 'Izveidot',
  'LBL_CURRENT_USER_FILTER' => 'Tikai mani ieraksti:',
  'LBL_DATE_ENTERED' => 'Izveidots:',
  'LBL_DATE_MODIFIED' => 'Modificēts:',
  'LBL_DELETE' => 'Dzēst',
  'LBL_DELETED' => 'Dzēsts',
  'LBL_DELETE_BUTTON' => 'Dzēst',
  'LBL_DELETE_BUTTON_KEY' => 'D',
  'LBL_DELETE_BUTTON_LABEL' => 'Dzēst',
  'LBL_DELETE_BUTTON_TITLE' => 'Dzēst',
  'LBL_DIRECT_REPORTS' => 'Tiešās atskaites',
  'LBL_DISPLAY_COLUMNS' => 'Rādīt kolonnas',
  'LBL_DONE_BUTTON_KEY' => 'X',
  'LBL_DONE_BUTTON_LABEL' => 'Darīts',
  'LBL_DONE_BUTTON_TITLE' => 'Darīts',
  'LBL_DST_NEEDS_FIXIN' => 'Lietojumprogramma pieprasa veikt Vasaras laika labojumu.  Lūdzu dodies uz <a href="index.php?module=Administration&action=DstFix">Salabot</a> Administrēšanas sadaļā un veic Vasaras laika labojumu.',
  'LBL_DUPLICATE_BUTTON' => 'Dublikāts',
  'LBL_DUPLICATE_BUTTON_KEY' => 'U',
  'LBL_DUPLICATE_BUTTON_LABEL' => 'Dublikāts',
  'LBL_DUPLICATE_BUTTON_TITLE' => 'Dublikāts',
  'LBL_DUP_MERGE' => 'Atrast dublikātus',
  'LBL_EDIT_BUTTON' => 'Rediģēt',
  'LBL_EDIT_BUTTON_KEY' => 'E',
  'LBL_EDIT_BUTTON_LABEL' => 'Rediģēt',
  'LBL_EDIT_BUTTON_TITLE' => 'Rediģēt',
  'LBL_EMAILS' => 'E-pasti',
  'LBL_EMAIL_PDF_BUTTON_KEY' => 'M',
  'LBL_EMAIL_PDF_BUTTON_LABEL' => 'E-pasts PDF formātā',
  'LBL_EMAIL_PDF_BUTTON_TITLE' => 'E-pasts PDF formātā',
  'LBL_EMPLOYEES' => 'Darbinieki',
  'LBL_ENTER_DATE' => 'Ievades datums',
  'LBL_EXPORT' => 'Eksports',
  'LBL_EXPORT_ALL' => 'Eksportēt visu',
  'LBL_FULL_FORM_BUTTON_KEY' => 'F',
  'LBL_FULL_FORM_BUTTON_LABEL' => 'Pilna ekrānforma',
  'LBL_FULL_FORM_BUTTON_TITLE' => 'Pilna ekrānforma',
  'LBL_HIDE' => 'Slēpt',
  'LBL_HIDE_COLUMNS' => 'Paslēpt kolonnas',
  'LBL_ID' => 'ID',
  'LBL_IMPORT' => 'Imports',
  'LBL_IMPORT_PROSPECTS' => 'Importēt mērķus',
  'LBL_LAST_VIEWED' => 'Pēdējā apskate',
  'LBL_LEADS' => 'Interesenti',
  'LBL_LISTVIEW_MASS_UPDATE_CONFIRM' => 'Vai jūs esat pārliecināts, ka vēlaties atjaunināt visu sarakstu?',
  'LBL_LISTVIEW_NO_SELECTED' => 'Lūdzu, izvēlaties vismaz vienu ierakstu, ko apstrādāt.',
  'LBL_LISTVIEW_OPTION_CURRENT' => 'Patreizējā lapa',
  'LBL_LISTVIEW_OPTION_ENTIRE' => 'Viss saraksts',
  'LBL_LISTVIEW_OPTION_SELECTED' => 'Atzīmētie ieraksti',
  'LBL_LISTVIEW_SELECTED_OBJECTS' => 'Atzīmēti:',
  'LBL_LIST_ACCOUNT_NAME' => 'Uzņēmuma nosaukums',
  'LBL_LIST_ASSIGNED_USER' => 'Lietotājs',
  'LBL_LIST_CONTACT_NAME' => 'Kontaktpersonas vārds',
  'LBL_LIST_CONTACT_ROLE' => 'Kontaktpersonas loma:',
  'LBL_LIST_EMAIL' => 'E-pasts',
  'LBL_LIST_NAME' => 'Nosaukums',
  'LBL_LIST_OF' => 'pēc',
  'LBL_LIST_PHONE' => 'Tālrunis',
  'LBL_LIST_TEAM' => 'Darba grupa',
  'LBL_LIST_USER_NAME' => 'Lietotāja vārds',
  'LBL_LOADING' => 'Ielādē ...',
  'LBL_LOCALE_NAME_EXAMPLE_FIRST' => 'John',
  'LBL_LOCALE_NAME_EXAMPLE_LAST' => 'Doe',
  'LBL_LOCALE_NAME_EXAMPLE_SALUTATION' => 'Mr.',
  'LBL_LOGIN_SESSION_EXCEEDED' => 'Serveris ir pārāk noslogots. Lūdzu vēlāk mēģiniet vēlreiz.',
  'LBL_LOGIN_TO_ACCESS' => 'Lūdzu piesakieties sistēmā, lai piekļūtu šim apgabalam.',
  'LBL_LOGOUT' => 'Iziet',
  'LBL_MAILMERGE' => 'Pasta sapludināšana',
  'LBL_MAILMERGE_KEY' => 'M',
  'LBL_MASS_UPDATE' => 'Masveida izmaiņas',
  'LBL_MEETINGS' => 'Tikšanās',
  'LBL_MEMBERS' => 'Dalībnieki',
  'LBL_MODIFIED' => 'Modificēja',
  'LBL_MODIFIED_BY_USER' => 'Modificēja lietotājs',
  'LBL_MY_ACCOUNT' => 'Mans konts',
  'LBL_NAME' => 'Nosaukums',
  'LBL_NEW_BUTTON_KEY' => 'N',
  'LBL_NEW_BUTTON_LABEL' => 'Izveidot',
  'LBL_NEW_BUTTON_TITLE' => 'Izveidot',
  'LBL_NEXT_BUTTON_LABEL' => 'Nākamais',
  'LBL_NONE' => '--Neviens--',
  'LBL_NOTES' => 'Piezīmes',
  'LBL_NO_RECORDS_FOUND' => '- 0 ieraksti atrasti -',
  'LBL_OPENALL_BUTTON_KEY' => 'O',
  'LBL_OPENALL_BUTTON_LABEL' => 'Atvērt visu',
  'LBL_OPENALL_BUTTON_TITLE' => 'Atvērt visu',
  'LBL_OPENTO_BUTTON_KEY' => 'T',
  'LBL_OPENTO_BUTTON_LABEL' => 'Atvērt uz:',
  'LBL_OPENTO_BUTTON_TITLE' => 'Atvērt uz:',
  'LBL_OPPORTUNITIES' => 'Iespējas',
  'LBL_OPPORTUNITY' => 'Iespēja',
  'LBL_OPPORTUNITY_NAME' => 'Iespējas nosaukums',
  'LBL_OR' => 'OR',
  'LBL_PERCENTAGE_SYMBOL' => '%',
  'LBL_PRODUCTS' => 'Produkti',
  'LBL_PRODUCT_BUNDLES' => 'Produktu pakas',
  'LBL_PROJECTS' => 'Projekti',
  'LBL_PROJECT_TASKS' => 'Projekta uzdevumi',
  'LBL_QUOTES' => 'Piedāvājumi',
  'LBL_QUOTES_SHIP_TO' => 'Piedāvājumus piegādāt uz',
  'LBL_QUOTE_TO_OPPORTUNITY_KEY' => 'O',
  'LBL_QUOTE_TO_OPPORTUNITY_LABEL' => 'Izveidot iespēju no piedāvājuma',
  'LBL_QUOTE_TO_OPPORTUNITY_TITLE' => 'Izveidot iespēju no piedāvājuma',
  'LBL_RELATED_RECORDS' => 'Saistītie ieraksti',
  'LBL_REMOVE' => 'Noņemt',
  'LBL_REQUIRED_SYMBOL' => '*',
  'LBL_SAVED' => 'Saglabāts',
  'LBL_SAVED_LAYOUT' => 'Izkārtojums saglabāts.',
  'LBL_SAVED_VIEWS' => 'Saglabātie skatījumi',
  'LBL_SAVE_BUTTON_KEY' => 'S',
  'LBL_SAVE_BUTTON_LABEL' => 'Saglabāt',
  'LBL_SAVE_BUTTON_TITLE' => 'Saglabāt',
  'LBL_SAVE_NEW_BUTTON_KEY' => 'V',
  'LBL_SAVE_NEW_BUTTON_LABEL' => 'Saglabāt un veidot jaunu',
  'LBL_SAVE_NEW_BUTTON_TITLE' => 'Saglabāt un veidot jaunu',
  'LBL_SAVING' => 'Saglabā',
  'LBL_SAVING_LAYOUT' => 'Saglabā izkārtojumu ...',
  'LBL_SEARCH' => 'Meklēt',
  'LBL_SEARCH_BUTTON_KEY' => 'Q',
  'LBL_SEARCH_BUTTON_LABEL' => 'Meklēt',
  'LBL_SEARCH_BUTTON_TITLE' => 'Meklēšana',
  'LBL_SEARCH_CRITERIA' => 'Meklēšanas kritēriji',
  'LBL_SELECT_BUTTON_KEY' => 'T',
  'LBL_SELECT_BUTTON_LABEL' => 'Izvēlēties',
  'LBL_SELECT_BUTTON_TITLE' => 'Izvēlēties',
  'LBL_SELECT_CONTACT_BUTTON_KEY' => 'T',
  'LBL_SELECT_CONTACT_BUTTON_LABEL' => 'Izvēlēties kontaktpersonu',
  'LBL_SELECT_CONTACT_BUTTON_TITLE' => 'Izvēlēties kontaktpersonu',
  'LBL_SELECT_REPORTS_BUTTON_LABEL' => 'Izvēlēties no atskaitēm',
  'LBL_SELECT_REPORTS_BUTTON_TITLE' => 'Izvēlēties atskaites',
  'LBL_SELECT_USER_BUTTON_KEY' => 'U',
  'LBL_SELECT_USER_BUTTON_LABEL' => 'Izvēlēties lietotāju',
  'LBL_SELECT_USER_BUTTON_TITLE' => 'Izvēlēties lietotāju',
  'LBL_SERVER_RESPONSE_RESOURCES' => 'Šīs lapas veidošanā izmantotie servera resursi (SQL vaicājumi, faili)',
  'LBL_SERVER_RESPONSE_TIME' => 'Servera reakcijas laiks:',
  'LBL_SERVER_RESPONSE_TIME_SECONDS' => 'sekundes.',
  'LBL_SHIP_TO_ACCOUNT' => 'Piegādāt uzņēmumam',
  'LBL_SHIP_TO_CONTACT' => 'Piegādāt kontaktpersonai',
  'LBL_SHORTCUTS' => 'Saīsnes',
  'LBL_SHOW' => 'Rādīt',
  'LBL_SQS_INDICATOR' => '',
  'LBL_STATUS' => 'Statuss:',
  'LBL_STATUS_UPDATED' => 'Jūsu statuss šajā notikumā ir izmainīts!',
  'LBL_SUBJECT' => 'Temats',
  'LBL_SYNC' => 'Sinhronizācija',
  'LBL_TASKS' => 'Uzdevumi',
  'LBL_TEAM' => 'Darba grupa',
  'LBL_TEAMS_LINK' => 'Darba grupa',
  'LBL_TEAM_ID' => 'Darba grupas ID:',
  'LBL_THOUSANDS_SYMBOL' => 'K',
  'LBL_TRACK_EMAIL_BUTTON_KEY' => 'K',
  'LBL_TRACK_EMAIL_BUTTON_LABEL' => 'Arhivēt e-pastu',
  'LBL_TRACK_EMAIL_BUTTON_TITLE' => 'Arhivēt e-pastu',
  'LBL_UNAUTH_ADMIN' => 'Neautorizēta piekļuve administratora funkcijām',
  'LBL_UNDELETE' => 'Atsaukt dzēšanu',
  'LBL_UNDELETE_BUTTON' => 'Atsaukt dzēšanu',
  'LBL_UNDELETE_BUTTON_LABEL' => 'Atsaukt dzēšanu',
  'LBL_UNDELETE_BUTTON_TITLE' => 'Atsaukt dzēšanu',
  'LBL_UNSYNC' => 'Atcelt sinhronizēšanu',
  'LBL_UPDATE' => 'Atjaunināt',
  'LBL_USERS' => 'Lietotāji',
  'LBL_USERS_SYNC' => 'Lietotāju sinhronizēšana',
  'LBL_USER_LIST' => 'Lietotāju saraksts',
  'LBL_VIEW_BUTTON' => 'Apskatīt',
  'LBL_VIEW_BUTTON_KEY' => 'V',
  'LBL_VIEW_BUTTON_LABEL' => 'Apskatīt',
  'LBL_VIEW_BUTTON_TITLE' => 'Apskatīt',
  'LBL_VIEW_PDF_BUTTON_KEY' => 'P',
  'LBL_VIEW_PDF_BUTTON_LABEL' => 'Izdrukāt PDF formātā',
  'LBL_VIEW_PDF_BUTTON_TITLE' => 'Izdrukāt PDF formātā',
  'LNK_ABOUT' => 'Par produktu',
  'LNK_ADVANCED_SEARCH' => 'Paplašinātā meklēšana',
  'LNK_BASIC_SEARCH' => 'Pamata meklēšana',
  'LNK_DELETE' => 'dzēst',
  'LNK_DELETE_ALL' => 'dzēst visu',
  'LNK_EDIT' => 'rediģēt',
  'LNK_GET_LATEST' => 'Iegūt jaunāko',
  'LNK_GET_LATEST_TOOLTIP' => 'Aizvietot ar jaunāko versiju',
  'LNK_HELP' => 'Palīdzība',
  'LNK_LIST_END' => 'Beigas',
  'LNK_LIST_NEXT' => 'Nākamais',
  'LNK_LIST_PREVIOUS' => 'Iepriekšējais',
  'LNK_LIST_RETURN' => 'Atgriezties sarakstā',
  'LNK_LIST_START' => 'Sākums',
  'LNK_LOAD_SIGNED' => 'Parakstīt',
  'LNK_LOAD_SIGNED_TOOLTIP' => 'Aizvietot ar parakstītu dokumentu',
  'LNK_PRINT' => 'Drukāt',
  'LNK_REMOVE' => 'noņemt',
  'LNK_RESUME' => 'Atsākt',
  'LNK_VIEW_CHANGE_LOG' => 'Apskatīt izmaiņu žurnālu',
  'LOGIN_LOGO_ERROR' => 'Lūdzu, mainiet SugarCRM logo attēlus.',
  'NTC_CLICK_BACK' => 'Spiediet pārlūka pogu &#39;Back&#39; un izlabojiet kļūdu.',
  'NTC_DATE_FORMAT' => '(yyyy-mm-dd)',
  'NTC_DATE_TIME_FORMAT' => '(yyyy-mm-dd 24:00)',
  'NTC_DELETE_CONFIRMATION' => 'Vai tiešām vēlaties dzēst šo ierakstu?',
  'NTC_DELETE_CONFIRMATION_MULTIPLE' => 'Vai tiešām vēlaties dzēst  atzīmētos ierakstus?',
  'NTC_LOGIN_MESSAGE' => 'Lūdzu ievadi savu lietotājvārdu un paroli:',
  'NTC_NO_ITEMS_DISPLAY' => 'neviens',
  'NTC_REMOVE_CONFIRMATION' => 'Vai tiešām vēlaties noņemt šo relāciju?',
  'NTC_REQUIRED' => 'Norāda obligāto lauku',
  'NTC_SUPPORT_SUGARCRM' => 'Varat atbalstīt SugarCRM atvērtā koda projektu ar ziedojumu, izmantojot PayPal maksājumu sistēmu - tas ir ātri, vbezmaksas un droši!',
  'NTC_TIME_FORMAT' => '(24:00)',
  'NTC_WELCOME' => 'Sveiki',
  'NTC_YEAR_FORMAT' => '(yyyy)',
);

