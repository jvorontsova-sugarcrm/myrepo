<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');


/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Master Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/master-subscription-agreement
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2012 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/

	

$mod_strings = array (
  'ERROR_BAD_RESULT' => 'Servis je vratio loš rezultat',
  'ERROR_NO_CURL' => 'cURL ekstenzija je neophodna, a nije omogućena',
  'ERROR_REQUEST_FAILED' => 'Nije moguće kontaktirati server',
  'LBL_CANCEL_BUTTON_TITLE' => 'Otkaži',
  'LBL_CONFIGURE_SNIP' => 'Arhiviranje Email poruka',
  'LBL_CONTACT_SUPPORT' => 'Molimo pokušajte ponovo ili kontaktirajte SugarCRM podršku',
  'LBL_DISABLE_SNIP' => 'Onemogući',
  'LBL_REGISTER_SNIP_FAIL' => 'Neuspešno kotaktiranje servisa za arhiviranje email poruka: %s!',
  'LBL_SNIP_ACCOUNT' => 'Kompanija',
  'LBL_SNIP_AGREE' => 'Slažem se sa gore navedenim uslovima i <a href=$#39;http://www.sugarcrm.com/crm/TRUSTe/privacy.html$#39; target=$#39;_blank$#39;>sporazumom o privatnosti</a>.',
  'LBL_SNIP_APPLICATION_UNIQUE_KEY' => 'Jedinstveni ključ aplikacije',
  'LBL_SNIP_BUTTON_DISABLE' => 'Isključi arhiviranje email poruka',
  'LBL_SNIP_BUTTON_ENABLE' => 'Omogući arhiviranje email poruka',
  'LBL_SNIP_BUTTON_RETRY' => 'Pokušaj da se konektuješ',
  'LBL_SNIP_CALLBACK_URL' => 'URL servisa za arhiviranje email poruka',
  'LBL_SNIP_DESCRIPTION' => 'Servis za arhiviranje email poruka je sistem za automatsko arhiviranje email poruka.',
  'LBL_SNIP_DESCRIPTION_SUMMARY' => 'Omogućuje vam da vidiite email poruke koje su Vam slali kontakti unutar SugarCRM aplikacije, bez potrebe da ručno uvozite i povezujete poruke.',
  'LBL_SNIP_EMAIL' => 'Adresa za arhiviranje email poruka',
  'LBL_SNIP_ERROR_DISABLING' => 'Došlo je do greške pri pokušaju komunikacije sa servierom za arhiviranje email poruka i servis nije isključen',
  'LBL_SNIP_ERROR_ENABLING' => 'Došlo je do greške pri pokušaju komunikacije sa servierom za arhiviranje email poruka i servis nije omogućen',
  'LBL_SNIP_GENERIC_ERROR' => 'Servis za arhiviranje email poruka je trenutno nedostupan. Server je pao ili je konekcija sa ovom Sugar instancom neuspela.',
  'LBL_SNIP_KEY_DESC' => 'OAuth ključ za arhiviranje email poruka. Koristi se za pristup instanci u svrhu uvoza email poruka.',
  'LBL_SNIP_LAST_SUCCESS' => 'Poslednje uspešno pokretanje.',
  'LBL_SNIP_MOUSEOVER_EMAIL' => 'Ovo je email adresa za arhiviranje emailova na koju je potrebno lsati kako bi se uvezli mailovi u Sugar',
  'LBL_SNIP_MOUSEOVER_INSTANCE_URL' => 'Ovo je URL web servisa Vaše Sugar instance. Server za arhiviranje email poruka će se povezati na Vaš server kroz ovaj URL.',
  'LBL_SNIP_MOUSEOVER_SERVICE_URL' => 'Ovo je URL servera za arhiviranje email poruka. Svi zahtevi, uključujući omogućavanje i isključivanje servisa, biće prosleđeni kroz ovaj URL.',
  'LBL_SNIP_MOUSEOVER_STATUS' => 'Ovo je status servisa za arhiviranje email poruka na Vašoj instanci. Status zavisi od toga da li je konekcija servera za arhiviranje email poruka i Vaše Sugar instance bila uspešna.',
  'LBL_SNIP_NEVER' => 'Nikad',
  'LBL_SNIP_PRIVACY' => 'sporazum o privatnosti',
  'LBL_SNIP_PURCHASE' => 'Klikni ovde da kupiš',
  'LBL_SNIP_PURCHASE_SUMMARY' => 'Kako biste koristili arhiviranje email poruka, morate kupiti licencu za Vašu SugarCRM instancu',
  'LBL_SNIP_PWD' => 'Šifra za arhiviranje email poruka',
  'LBL_SNIP_STATUS' => 'Status',
  'LBL_SNIP_STATUS_ERROR' => 'Greška',
  'LBL_SNIP_STATUS_ERROR_SUMMARY' => 'Ova instanca ima validnu licencu za arhiviranje email poruka, ali je server vratio sledeću poruku o grešci:',
  'LBL_SNIP_STATUS_FAIL' => 'Nemoguće je registrovati se na server za arhiviranje email poruka',
  'LBL_SNIP_STATUS_FAIL_SUMMARY' => 'Servis za arhiviranje email poruka je trenutno nedostupan. Ili je server pao ili je konekcija na ovu Sugar instancu neuspela.',
  'LBL_SNIP_STATUS_OK' => 'Omogućeno',
  'LBL_SNIP_STATUS_OK_SUMMARY' => 'Ova Sugar instanca je uspešno konektovana na server za arhiviranje email poruka',
  'LBL_SNIP_STATUS_PINGBACK_FAIL' => 'Kontaktiranje neuspelo',
  'LBL_SNIP_STATUS_PINGBACK_FAIL_SUMMARY' => 'Server za arhiviranje email poruka nije u mogućnosti da uspostavi konekciju sa Vašom Sugar instancom. Molimo pokušajte kasnije ili kontaktirajte korisničku podršku.',
  'LBL_SNIP_STATUS_PROBLEM' => 'Problem: %s',
  'LBL_SNIP_STATUS_RESET' => 'Još uvek nije pokrenuta',
  'LBL_SNIP_STATUS_SUMMARY' => 'Status servisa za arhiviranje email poruka:',
  'LBL_SNIP_SUGAR_URL' => 'URL Sugar instance',
  'LBL_SNIP_SUMMARY' => 'Arhiviranje email poruka je automastki servis za uvoz koji korisnicima omogućava da uvezu email poruke u Sugar slanjem istih sa bilo kog mail klijenta ili servisa na email adresu koju obezbeđuje Sugar. Svaka Sugar instanca ima jedinstvenu email adresu. Da bi uvezao email poruke, korisnik šalje na datu email adresu koristeći polja TO, CC, BCC. Servis za arhiviranje email poruka će email poruke uvesti na Sugar instancu. Servis uvozi email, zajedno sa svim zakačenim fajlovima, slikama i kalendarskim događajima i napraviti zapise u okviru aplikacije koji su povezani sa postojećim zapisima po osnovu poklapajućih email adresa.<br /><br /><br /><br />Primer: Kao korisnik, kada pregledam kompaniju, u mogućnosti sam da vidim sve email poruke koje su pvezane sa kompanijom na osnovu email adrese u zapisu kompanije. Takođe ću videti i email poruke koje su povezane sa kontaktima vezanim za kompaniju.<br /><br /><br /><br />Prihvatite uslove date ispod i kliknite na "Omogući" kako biste počeli da koristite servis. Bićete u mogućnosti da ga isključite u bilo kom momentu. Kada je omogućen, biće prikazana email adresa koju će servis koristiti.',
  'LBL_SNIP_SUPPORT' => 'Molimo kontaktirajte SugarCRM podršku.',
  'LBL_SNIP_USER' => 'Korisnik arhiviranja email poruka',
  'LBL_SNIP_USER_DESC' => 'Korisnik arhiviranja email poruka',
);

