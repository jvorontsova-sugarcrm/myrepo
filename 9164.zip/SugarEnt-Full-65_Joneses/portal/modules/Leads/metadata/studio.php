<?php
$studioDef = array(
	'editviewdefs'=>array('view'=>'edit', 'label'=>'LBL_EDITVIEW'),

);
?>