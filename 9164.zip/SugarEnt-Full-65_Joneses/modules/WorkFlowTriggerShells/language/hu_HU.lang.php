<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');


/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Master Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/master-subscription-agreement
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2012 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/

	

$mod_strings = array (
  'LBL_ALERT_TEMPLATES' => 'Riasztási sablonok',
  'LBL_APOSTROPHE_S' => ' ',
  'LBL_COMPARE_ANY_TIME_PART2' => 'nem változik',
  'LBL_COMPARE_ANY_TIME_PART3' => 'meghatározott ideig',
  'LBL_COMPARE_ANY_TIME_TITLE' => 'A mező nem változik egy meghatározott ideig',
  'LBL_COMPARE_CHANGE_PART' => 'változik',
  'LBL_COMPARE_CHANGE_TITLE' => 'Amikor egy mező a célmodulon megváltozik',
  'LBL_COMPARE_COUNT_TITLE' => 'Indítás a meghatározott számlálónál',
  'LBL_COMPARE_SPECIFIC_PART' => 'átvált egy meghatározott értékről vagy egy meghatározott értékre',
  'LBL_COMPARE_SPECIFIC_PART_TIME' => ' ',
  'LBL_COMPARE_SPECIFIC_TITLE' => 'Amikor egy mező a célmodulban átvált egy meghatározott értékről vagy egy meghatározott értékre',
  'LBL_COUNT_TRIGGER1' => 'Összesen',
  'LBL_COUNT_TRIGGER1_2' => 'összehasonlítva ezzel az összeggel',
  'LBL_COUNT_TRIGGER2' => 'Szűrés kapcsolódás alapján',
  'LBL_COUNT_TRIGGER2_2' => 'csak',
  'LBL_COUNT_TRIGGER3' => 'szűrés kimondottan a következő szerint',
  'LBL_COUNT_TRIGGER4' => 'másodlagos szűrés',
  'LBL_EVAL' => 'Indítás értékelés:',
  'LBL_FIELD' => 'Mező',
  'LBL_FILTER_FIELD_PART1' => 'Szűrés ... szerint:',
  'LBL_FILTER_FIELD_TITLE' => 'Amikor a célmodul tartalmaz egy meghatározott értéket',
  'LBL_FILTER_FORM_TITLE' => 'Adjon meg egy munkafolyamat feltételt',
  'LBL_FILTER_LIST_STATEMEMT' => 'Szűrés a követkő feltételek alapján:',
  'LBL_FILTER_REL_FIELD_PART1' => 'Adja meg a kapcsolódó',
  'LBL_FILTER_REL_FIELD_TITLE' => 'Amikor a cél modul megváltozik és egy mező egy kapcsolódó modulban tartalmaz egy meghatározott értéket',
  'LBL_FUTURE_TRIGGER' => 'Adja meg az új',
  'LBL_LIST_EVAL' => 'Értékelés:',
  'LBL_LIST_FIELD' => 'Mező:',
  'LBL_LIST_FORM_TITLE' => 'Indításlista',
  'LBL_LIST_FRAME_PRI' => 'Indítás:',
  'LBL_LIST_FRAME_SEC' => 'Szűrő:',
  'LBL_LIST_NAME' => 'Leírás:',
  'LBL_LIST_STATEMEMT' => 'Indítás a következő esemény alapján:',
  'LBL_LIST_TYPE' => 'Típus:',
  'LBL_LIST_VALUE' => 'Érték:',
  'LBL_MODULE' => 'modul',
  'LBL_MODULE_NAME' => 'Feltételek',
  'LBL_MODULE_SECTION_TITLE' => 'Amikor ezek a feltételek teljesülnek',
  'LBL_MODULE_TITLE' => 'Munkafolyamat indító: Főoldal',
  'LBL_MUST_SELECT_VALUE' => 'Válasszon értéket ennek a mezőnek',
  'LBL_NAME' => 'Indító neve:',
  'LBL_NEW_FILTER_BUTTON_KEY' => 'F',
  'LBL_NEW_FILTER_BUTTON_LABEL' => 'Új szűrő létrehozása',
  'LBL_NEW_FILTER_BUTTON_TITLE' => 'Új szűrő létrehozása',
  'LBL_NEW_FORM_TITLE' => 'Új indító létrehozása',
  'LBL_NEW_TRIGGER_BUTTON_KEY' => 'T',
  'LBL_NEW_TRIGGER_BUTTON_LABEL' => 'Új indító létrehozása',
  'LBL_NEW_TRIGGER_BUTTON_TITLE' => 'Új indító létrehozása',
  'LBL_PAST_TRIGGER' => 'Adja meg a régi',
  'LBL_RECORD' => 'modulé',
  'LBL_SEARCH_FORM_TITLE' => 'Munkafolyamat indító kereső',
  'LBL_SELECT_1ST_FILTER' => 'Válasszon ki egy érvényes elsődleges szűrőmezőt',
  'LBL_SELECT_2ND_FILTER' => 'Válasszon ki egy érvényes másodlagos szűrőmezőt',
  'LBL_SELECT_AMOUNT' => 'Válassza ki az összeget',
  'LBL_SELECT_OPTION' => 'Kérem, válasszon ki egy lehetőséget!',
  'LBL_SELECT_TARGET_FIELD' => 'Kérem, válasszon egy célterületet!',
  'LBL_SELECT_TARGET_MOD' => 'Kérem, válasszon egy célmodulhoz kapcsolódó modult!',
  'LBL_SHOW' => 'Mutat',
  'LBL_SHOW_PAST' => 'Korábbi érték módosítása:',
  'LBL_SPECIFIC_FIELD' => 'által meghatározott mező',
  'LBL_SPECIFIC_FIELD_LNK' => 'speciális mező',
  'LBL_TRIGGER' => 'Amikor',
  'LBL_TRIGGER_FILTER_TITLE' => 'Indító szűrők',
  'LBL_TRIGGER_FORM_TITLE' => 'Adjon meg egy feltételt a munkafolyamat végrehajtásához',
  'LBL_TRIGGER_RECORD_CHANGE_TITLE' => 'Amikor a célmodul változik',
  'LBL_TYPE' => 'Típus:',
  'LBL_VALUE' => 'érték',
  'LBL_WHEN_VALUE1' => 'Ha a mező értéke',
  'LBL_WHEN_VALUE2' => 'Ha az értéke',
  'LNK_NEW_TRIGGER' => 'Új indító létrehozása',
  'LNK_NEW_WORKFLOW' => 'Munkafolyamat létrehozása',
  'LNK_TRIGGER' => 'Munkafolyamat indítók',
  'LNK_WORKFLOW' => 'Munkafolyamat tárgyai',
  'NTC_REMOVE_TRIGGER' => 'Biztosan el akarja távolítani ezt az indítót?',
);

