<?php
$studioDef = array(
	'detailviewdefs'=>array('view'=>'detail', 'label'=>'LBL_DETAILVIEW'),
	'editviewdefs'=>array('view'=>'edit', 'label'=>'LBL_EDITVIEW'),
	'listviewdefs'=>array('view'=>'list', 'label'=>'LBL_LISTVIEW'),

);
?>