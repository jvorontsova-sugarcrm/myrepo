<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');


/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Master Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/master-subscription-agreement
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2012 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/

	

$app_list_strings = array (
  'account_type_dom' => 
  array (
    '' => '[-tuščias-]',
    'Analyst' => 'Analitikas',
    'Competitor' => 'Konkurentas',
    'Customer' => 'Pirkėjas',
    'Integrator' => 'Integruotojas',
    'Investor' => 'Investuotojas',
    'Other' => 'Kita',
    'Partner' => 'Partneris',
    'Press' => 'Spauda',
    'Prospect' => 'Kandidatas',
    'Reseller' => 'Perpardavėjas',
  ),
  'activity_dom' => 
  array (
    'Call' => 'Skambutis',
    'Email' => 'El. laiškas',
    'Meeting' => 'Susitikimas',
    'Note' => 'Užrašai',
    'Task' => 'Užduotis',
  ),
  'bopselect_type_dom' => 
  array (
    'Equals' => 'Lygus',
  ),
  'bselect_type_dom' => 
  array (
    'bool_false' => 'Ne',
    'bool_true' => 'Taip',
  ),
  'bug_priority_dom' => 
  array (
    'High' => 'Didelė',
    'Low' => 'Maža',
    'Medium' => 'Vidutinė',
    'Urgent' => 'Skubus',
  ),
  'bug_resolution_dom' => 
  array (
    '' => '',
    'Accepted' => 'Priimtas',
    'Duplicate' => 'Dublikatas',
    'Fixed' => 'Pataisytas',
    'Invalid' => 'Neteisingas',
    'Later' => 'Vėliau',
    'Out of Date' => 'Pasenęs',
  ),
  'bug_status_dom' => 
  array (
    'Assigned' => 'Priskirtas',
    'Closed' => 'Užbaigtas',
    'New' => 'Naujas',
    'Pending' => 'Laukiantis',
    'Rejected' => 'Atmestas',
  ),
  'bug_type_dom' => 
  array (
    'Defect' => 'Defektas',
    'Feature' => 'Savybė',
  ),
  'call_direction_dom' => 
  array (
    'Inbound' => 'Įeinantis',
    'Outbound' => 'Išeinantis',
  ),
  'call_status_dom' => 
  array (
    'Held' => 'Įvykęs',
    'Not Held' => 'Neįvykęs',
    'Planned' => 'Suplanuotas',
  ),
  'campaign_status_dom' => 
  array (
    '' => '',
    'Active' => 'Aktyvus',
    'Complete' => 'Užbaigtas',
    'In Queue' => 'Laukia eilėje',
    'Inactive' => 'Neaktyvus',
    'Planning' => 'Planuojamas',
    'Sending' => 'Siunčiamas',
  ),
  'campaign_type_dom' => 
  array (
    '' => '',
    'Email' => 'El. laiškas',
    'Mail' => 'Laiškas',
    'Print' => 'Spauda',
    'Radio' => 'Radijas',
    'Telesales' => 'Telepardavimai',
    'Television' => 'Televizija',
    'Web' => 'Tinklalapis',
  ),
  'campainglog_activity_type_dom' => 
  array (
    '' => '',
    'contact' => 'Kontaktai sukurti',
    'invalid email' => 'Neteisingas pašto adresas',
    'lead' => 'Potencialūs kontaktai sukurti',
    'link' => 'Paspaudė nuorodą',
    'removed' => 'Atsisakė naujienų',
    'send error' => 'Nepasiekė adresato',
    'targeted' => 'Laiškas išsiųstas',
    'viewed' => 'Pažiūrėjo laišką',
  ),
  'campainglog_target_type_dom' => 
  array (
    'Contacts' => 'Kontaktai',
    'Leads' => 'Potencialūs kontaktai',
    'Prospects' => 'Adresatai',
    'Users' => 'Vartotojai',
  ),
  'case_priority_dom' => 
  array (
    'P1' => 'Didelė',
    'P2' => 'Vidutinė',
    'P3' => 'Maža',
  ),
  'case_relationship_type_dom' => 
  array (
    '' => '',
    'Alternate Contact' => 'Alternatyvus kontaktas',
    'Primary Contact' => 'Pirminis kontaktas',
  ),
  'case_status_dom' => 
  array (
    'Assigned' => 'Priskirtas',
    'Closed' => 'Užbaigtas',
    'Duplicate' => 'Dublikatas',
    'New' => 'Naujas',
    'Pending Input' => 'Laukia',
    'Rejected' => 'Atmestas',
  ),
  'checkbox_dom' => 
  array (
    '' => '[-tuščias-]',
    1 => 'Taip',
    2 => 'Ne',
  ),
  'contract_expiration_notice_dom' => 
  array (
    1 => '1 diena',
    3 => '3 dienos',
    5 => '5 dienos',
    7 => '1 savaitė',
    14 => '2 savaitės',
    21 => '3 savaitės',
    31 => '1 mėnesis',
  ),
  'contract_payment_frequency_dom' => 
  array (
    'halfyearly' => 'Kas pusę metų',
    'monthly' => 'Mėnesinis',
    'quarterly' => 'Ketvirtinis',
    'yearly' => 'Metinis',
  ),
  'contract_status_dom' => 
  array (
    'inprogress' => 'Progrese',
    'notstarted' => 'Nepradėta',
    'signed' => 'Pasirašyta',
  ),
  'cselect_type_dom' => 
  array (
    'Does not Equal' => 'Nelygus',
    'Equals' => 'Lygus',
  ),
  'document_category_dom' => 
  array (
    '' => '',
    'Knowledege Base' => 'Žinių bazė',
    'Marketing' => 'Marketingas',
    'Sales' => 'Pardavimai',
  ),
  'document_status_dom' => 
  array (
    'Active' => 'Aktyvus',
    'Draft' => 'Juodraštis',
    'Expired' => 'Pasibaigęs',
    'FAQ' => 'DUK',
    'Pending' => 'Laukiantis',
    'Under Review' => 'Peržiūrimas',
  ),
  'document_subcategory_dom' => 
  array (
    '' => '',
    'FAQ' => 'DUK',
    'Marketing Collateral' => 'Rinkodaros dokumentai',
    'Product Brochures' => 'Prekių bukletai',
  ),
  'document_template_type_dom' => 
  array (
    '' => '',
    'eula' => 'EULA',
    'license' => 'Licencijos sutartis',
    'mailmerge' => 'Laiškų apjungimas',
    'nda' => 'NDA',
  ),
  'dom_cal_month_long' => 
  array (
    1 => 'Sausis',
    2 => 'Vasaris',
    3 => 'Kovas',
    4 => 'Balandis',
    5 => 'Gegužė',
    6 => 'Birželis',
    7 => 'Liepa',
    8 => 'Rugpjūtis',
    9 => 'Rugsėjis',
    10 => 'Spalis',
    11 => 'Lapkritis',
    12 => 'Gruodis',
  ),
  'dom_email_bool' => 
  array (
    'bool_false' => 'Ne',
    'bool_true' => 'Taip',
  ),
  'dom_email_distribution' => 
  array (
    '' => '--Joks--',
    'direct' => 'Tiesioginis priskyrimas',
    'leastBusy' => 'Mažiausiai užsiėmęs',
    'roundRobin' => 'Round-Robin',
  ),
  'dom_email_editor_option' => 
  array (
    '' => 'Numatytas pašto formatas',
    'html' => 'HTML laiškas',
    'plain' => 'Paprastas tekstinis laiškas',
  ),
  'dom_email_errors' => 
  array (
    1 => 'Pasirinkite tik vieną vartotoją',
    2 => 'Turite priskirti tik pažymėtus elementus',
  ),
  'dom_email_link_type' => 
  array (
    '' => 'Numatytas pašto klientas',
    'mailto' => 'Išorinis pašto klientas',
    'sugar' => 'SugarCRM pašto klientas',
  ),
  'dom_email_server_type' => 
  array (
    '' => '--Joks--',
    'imap' => 'IMAP',
    'pop3' => 'POP3',
  ),
  'dom_email_status' => 
  array (
    'archived' => 'Suarchyvuotas',
    'closed' => 'Užbaigtas',
    'draft' => 'Juodraštis',
    'read' => 'Perskaitytas',
    'replied' => 'Atsakytas',
    'send_error' => 'Siuntimo klaida',
    'sent' => 'Išsiųstas',
    'unread' => 'Neperskaitytas',
  ),
  'dom_email_types' => 
  array (
    'archived' => 'Suarchyvuotas',
    'draft' => 'Juodraštinis',
    'inbound' => 'Įeinantis',
    'out' => 'Išsiųstas',
  ),
  'dom_int_bool' => 
  array (
    1 => 'Taip',
  ),
  'dom_mailbox_type' => 
  array (
    'bounce' => 'Nenuėjusių tvarkymas',
    'bug' => 'Sukurti klaidą',
    'contact' => 'Sukurti kontaktą',
    'pick' => 'Sukurti [Bet kokį]',
    'sales' => 'Sukurti potencialų kontaktą',
    'support' => 'Sukurti aptarnavimą',
    'task' => 'Sukurti užduotį',
  ),
  'dom_meeting_accept_options' => 
  array (
    'accept' => 'Patvirtinti',
    'decline' => 'Atsisakyti',
    'tentative' => 'Nežinoti',
  ),
  'dom_meeting_accept_status' => 
  array (
    'accept' => 'Patvirtinti',
    'decline' => 'Atsisakyti',
    'none' => 'Joks',
    'tentative' => 'Nežinoti',
  ),
  'dom_report_types' => 
  array (
    'detailed_summary' => 'Sumavimas su detalėmis',
    'summary' => 'Sumavimas',
    'tabular' => 'Eilutės ir stulpeliai',
  ),
  'dom_switch_bool' => 
  array (
    '' => 'Ne',
    'off' => 'Ne',
    'on' => 'Taip',
  ),
  'dom_timezones' => 
  array (
    -12 => '(GMT - 12) International Date Line West',
    -11 => '(GMT - 11) Midvėjaus salos,  Samoa',
    -10 => '(GMT - 10) Havajai',
    -9 => '(GMT - 9) Alaska',
    -8 => '(GMT - 8) San Franciskas',
    -7 => '(GMT - 7) Phoenix',
    -6 => '(GMT - 6) Saskatchewan',
    -5 => '(GMT - 5) Niujorkas',
    -4 => '(GMT - 4) Santjagas',
    -3 => '(GMT - 3) Buenos Airės',
    -2 => '(GMT - 2) Mid-Atlantic',
    -1 => '(GMT - 1) Azorų',
    1 => '(GMT + 1) Madridas',
    2 => '(GMT + 2) Atėnai',
    3 => '(GMT + 3) Maskva',
    4 => '(GMT + 4) Kabulas',
    5 => 'GMT + 5) Jekaterinburgas',
    6 => '(GMT + 6) Astana',
    7 => '(GMT + 7) Bankokas',
    8 => '(GMT + 8) Pertas',
    9 => '(GMT + 9) Seulas',
    10 => '(GMT + 10) Brisbenas',
    11 => '(GMT + 11) Saliamono salos',
    12 => '(GMT + 12) Auckland',
  ),
  'dom_timezones_extra' => 
  array (
    -12 => '(GMT-12) International Date Line West',
    -11 => '(GMT-11) Midvėjau salos, Samoa',
    -10 => '(GMT-10) Havajai',
    -9 => '(GMT-9) Alaska',
    -8 => '(GMT-8) (PST)',
    -7 => '(GMT-7) (MST)',
    -6 => '(GMT-6) (CST)',
    -5 => '(GMT-5) (EST)',
    -4 => '(GMT-4) Santjagas',
    -3 => '(GMT-3) Buenos Airės',
    -2 => '(GMT-2) Mid-Atlantic',
    -1 => '(GMT-1) Azorų',
    1 => '(GMT+1) Madridas',
    2 => '(GMT+2) Atėnai',
    3 => '(GMT+3) Maskva',
    4 => '(GMT+4) Kabulas',
    5 => '(GMT+5) Jekaterinburgas',
    6 => '(GMT+6) Astana',
    7 => '(GMT+7) Bankokas',
    8 => '(GMT+8) Pertas',
    9 => '(GMT+9) Seulas',
    10 => '(GMT+10) Brisbanas',
    11 => '(GMT+11) Saliamono salos',
    12 => '(GMT+12) Auckland',
  ),
  'dselect_type_dom' => 
  array (
    'Does not Equal' => 'Nelygus',
    'Equals' => 'Lygus',
    'Less Than' => 'yra mažiau nei',
    'More Than' => 'Daugiau nei',
  ),
  'dtselect_type_dom' => 
  array (
    'Less Than' => 'yra mažiau nei',
    'More Than' => 'buvo daugiau nei',
  ),
  'duration_intervals' => 
  array (
    15 => '15',
    30 => '30',
    45 => '45',
  ),
  'email_marketing_status_dom' => 
  array (
    '' => '',
    'active' => 'Aktyvus',
    'inactive' => 'Neaktyvus',
  ),
  'employee_status_dom' => 
  array (
    'Active' => 'Aktyvus',
    'Leave of Absence' => 'Ne darbe',
    'Terminated' => 'Nutrauktas',
  ),
  'forecast_schedule_status_dom' => 
  array (
    'Active' => 'Aktyvus',
    'Inactive' => 'Neaktyvus',
  ),
  'forecast_type_dom' => 
  array (
    'Direct' => 'Tiesioginis',
    'Rollup' => 'Kaupiamasis',
  ),
  'industry_dom' => 
  array (
    '' => '',
    'Apparel' => 'Drabužiai',
    'Banking' => 'Bankai',
    'Biotechnology' => 'Biotechnologijos',
    'Chemicals' => 'Chemija',
    'Communications' => 'Ryšiai',
    'Construction' => 'Statybos',
    'Consulting' => 'Konsultavimas',
    'Education' => 'Švietimas',
    'Electronics' => 'Elektronika',
    'Energy' => 'Energetika',
    'Engineering' => 'Inžinerija',
    'Entertainment' => 'Pramogos',
    'Environmental' => 'Aplinkosauga',
    'Finance' => 'Finansai',
    'Government' => 'Vyriausybė',
    'Healthcare' => 'Gydymas',
    'Hospitality' => 'Apgyvendinimas',
    'Insurance' => 'Draudimas',
    'Machinery' => 'Technika',
    'Manufacturing' => 'Gamyba',
    'Media' => 'Žiniasklaida',
    'Not For Profit' => 'Ne pelno',
    'Other' => 'Kita',
    'Recreation' => 'Poilsis',
    'Retail' => 'Mažmeninė prekyba',
    'Shipping' => 'Laivyba',
    'Technology' => 'Technologijos',
    'Telecommunications' => 'Telekomunikacijos',
    'Transportation' => 'Transportavimas',
    'Utilities' => 'Komunalinės paslaugos',
  ),
  'language_pack_name' => 'Lietuvių',
  'layouts_dom' => 
  array (
    'Invoice' => 'Sąskaita',
    'Standard' => 'Pasiūlymas',
    'Terms' => 'Mokėjimo sąlygos',
  ),
  'lead_source_dom' => 
  array (
    '' => '',
    'Cold Call' => 'Aktyvūs pardavimai',
    'Conference' => 'Konferencija',
    'Direct Mail' => 'Tiesioginis paštas',
    'Email' => 'El. laiškas',
    'Employee' => 'Darbuotojai',
    'Existing Customer' => 'Esamas klientas',
    'Other' => 'Kita',
    'Partner' => 'Partneris',
    'Public Relations' => 'Viešieji ryšiai',
    'Self Generated' => 'Pats kreipėsi',
    'Trade Show' => 'Paroda',
    'Web Site' => 'Tinklapis',
    'Word of mouth' => 'Rekomendacija',
  ),
  'lead_status_dom' => 
  array (
    '' => '',
    'Assigned' => 'Priskirtas',
    'Converted' => 'Konvertuotas',
    'Dead' => 'Netinkamas',
    'In Process' => 'Progrese',
    'New' => 'Naujas',
    'Recycled' => 'Atnaujintas',
  ),
  'lead_status_noblank_dom' => 
  array (
    'Assigned' => 'Priskirtas',
    'Converted' => 'Konvertuotas',
    'Dead' => 'Netinkamas',
    'In Process' => 'Progrese',
    'New' => 'Naujas',
    'Recycled' => 'Atnaujintas',
  ),
  'meeting_status_dom' => 
  array (
    'Held' => 'Įvykęs',
    'Not Held' => 'Neįvykęs',
    'Planned' => 'Suplanuotas',
  ),
  'messenger_type_dom' => 
  array (
    '' => '',
    'AOL' => 'AOL',
    'MSN' => 'MSN',
    'Yahoo!' => 'Yahoo!',
  ),
  'moduleList' => 
  array (
    'Bugs' => 'Klaidos',
    'Cases' => 'Aptarnavimai',
    'FAQ' => 'DUK',
    'Home' => 'Pradžia',
    'KBDocuments' => 'Žinių bazė',
    'Newsletters' => 'Naujienlaiškis',
    'Notes' => 'Užrašai',
    'Teams' => 'Komandos',
    'Users' => 'Vartotojai',
  ),
  'moduleListSingular' => 
  array (
    'Bugs' => 'Klaida',
    'Cases' => 'Aptarnavimas',
    'Home' => 'Pradžia',
    'Notes' => 'Užrašas',
    'Teams' => 'Komanda',
    'Users' => 'Vartotojas',
  ),
  'mselect_type_dom' => 
  array (
    'Equals' => 'Lygus',
    'in' => 'Yra viena iš',
  ),
  'notifymail_sendtype' => 
  array (
    'SMTP' => 'SMTP',
  ),
  'opportunity_relationship_type_dom' => 
  array (
    '' => '',
    'Business Decision Maker' => 'Verslo sprendimo priėmėjas',
    'Business Evaluator' => 'Verslo įvertintojas',
    'Executive Sponsor' => 'Vadovaujantis rėmėjas',
    'Influencer' => 'Įtakotojas',
    'Other' => 'Kita',
    'Primary Decision Maker' => 'Pagrindinis sprendimo priėmėjas',
    'Technical Decision Maker' => 'Techninio sprendimo priėmėjas',
    'Technical Evaluator' => 'Techninis įvertintojas',
  ),
  'opportunity_type_dom' => 
  array (
    '' => '',
    'Existing Business' => 'Esamas verslas',
    'New Business' => 'Naujas verslas',
  ),
  'order_stage_dom' => 
  array (
    'Cancelled' => 'Atšaukta',
    'Confirmed' => 'Patvirtintas',
    'On Hold' => 'Sulaikytas',
    'Pending' => 'Laukiantis',
    'Shipped' => 'Išsiųstas',
  ),
  'payment_terms' => 
  array (
    '' => '',
    'Net 15' => '15 d.',
    'Net 30' => '30 d.',
  ),
  'pricing_formula_dom' => 
  array (
    'Fixed' => 'Nustatytas',
    'IsList' => 'Ta pati kaip kainos',
    'PercentageDiscount' => 'Nuolaida nuo kainos',
    'PercentageMarkup' => 'Markup over Cost',
    'ProfitMargin' => 'Pelno marža',
  ),
  'product_category_dom' => 
  array (
    '' => '',
    'Accounts' => 'Klientai',
    'Activities' => 'Priminimai',
    'Bug Tracker' => 'Klaidos',
    'Calendar' => 'Kalendorius',
    'Calls' => 'Skambučiai',
    'Campaigns' => 'Kampanijos',
    'Cases' => 'Aptarnavimai',
    'Contacts' => 'Kontaktai',
    'Currencies' => 'Valiutos',
    'Dashboard' => 'Prietaisų skydas',
    'Documents' => 'Dokumentai',
    'Emails' => 'Laiškai',
    'Feeds' => 'Naujienos',
    'Forecasts' => 'Prognozės',
    'Help' => 'Pagalba',
    'Home' => 'Pradžia',
    'Leads' => 'Potencialus kontaktas',
    'Meetings' => 'Susitikimas',
    'Notes' => 'Užrašai',
    'Opportunities' => 'Pardavimai',
    'Outlook Plugin' => 'Outlook įskiepis',
    'Product Catalog' => 'Prekių katalogas',
    'Products' => 'Prekės',
    'Projects' => 'Projektai',
    'Quotes' => 'Pasiūlymai',
    'RSS' => 'RSS',
    'Releases' => 'Išleidimai',
    'Studio' => 'Studija',
    'Upgrade' => 'Atnaujinimai',
    'Users' => 'Vartotojai',
  ),
  'product_status_dom' => 
  array (
    'Orders' => 'Užsakyta',
    'Quotes' => 'Pasiūlyta',
    'Ship' => 'Išsiųsta',
  ),
  'product_status_quote_key' => 'Pasiūlymai',
  'product_template_status_dom' => 
  array (
    'Available' => 'Sandėlyje',
    'Unavailable' => 'Nėra sandėlyje',
  ),
  'project_task_priority_options' => 
  array (
    'High' => 'Didelė',
    'Low' => 'Maža',
    'Medium' => 'Vidutinė',
  ),
  'project_task_status_options' => 
  array (
    'Completed' => 'Užbaigta',
    'Deferred' => 'Atidėta',
    'In Progress' => 'Progrese',
    'Not Started' => 'Nepradėta',
    'Pending Input' => 'Laukia',
  ),
  'project_task_utilization_options' => 
  array (
    25 => '25',
    50 => '50',
    75 => '75',
    100 => '100',
  ),
  'prospect_list_type_dom' => 
  array (
    'default' => 'Numatytas',
    'exempt' => 'Atsisakiusių sąrašas - pagal Id',
    'exempt_address' => 'Atsisakiusių sąrašas - pagal pašto adresą',
    'exempt_domain' => 'Atsisakiusių sąrašas - pagal domeną',
    'seed' => 'Ne potencialūs klientai',
    'test' => 'Testas',
  ),
  'query_calc_oper_dom' => 
  array (
    '*' => '(X) Daugyba iš',
    '+' => '(+) Pliusas',
    '-' => '(-) Minusas',
    '/' => '(/) Dalyba iš',
  ),
  'quote_relationship_type_dom' => 
  array (
    '' => '',
    'Business Decision Maker' => 'Verslo sprendimo priėmėjas',
    'Business Evaluator' => 'Verslo įvertintojas',
    'Executive Sponsor' => 'Vadovaujantis rėmėjas',
    'Influencer' => 'Įtakotojas',
    'Other' => 'Kita',
    'Primary Decision Maker' => 'Pagrindinis sprendimo priėmėjas',
    'Technical Decision Maker' => 'Techninis sprendimo priėmėjas',
    'Technical Evaluator' => 'Techninis įvertintojas',
  ),
  'quote_stage_dom' => 
  array (
    'Closed Accepted' => 'Sėkmingas',
    'Closed Dead' => 'Netinkamas',
    'Closed Lost' => 'Nesėkmingas',
    'Confirmed' => 'Patvirtinta',
    'Delivered' => 'Pristatyta',
    'Draft' => 'Juodraštis',
    'Negotiation' => 'Derybos',
    'On Hold' => 'Sulaikyta',
  ),
  'quote_type_dom' => 
  array (
    'Orders' => 'Užsakymas',
    'Quotes' => 'Pasiūlymai',
  ),
  'record_type_display' => 
  array (
    'Accounts' => 'Klientas',
    'Bugs' => 'Klaida',
    'Cases' => 'Aptarnavimas',
    'Contacts' => 'Kontaktas',
    'Leads' => 'Potencialus kontaktas',
    'Opportunities' => 'Pardavimas',
    'ProductTemplates' => 'Prekė',
    'Project' => 'Projektas',
    'ProjectTask' => 'Projekto užduotis',
    'Quotes' => 'Pasiūlymas',
    'Tasks' => 'Užduotis',
  ),
  'record_type_display_notes' => 
  array (
    'Accounts' => 'Klientas',
    'Bugs' => 'Klaidos',
    'Calls' => 'Skambučiai',
    'Cases' => 'Aptarnavimas',
    'Contacts' => 'Kontaktas',
    'Contracts' => 'Sutartys',
    'Emails' => 'Laiškai',
    'Leads' => 'Potencialūs kontaktas',
    'Meetings' => 'Susitikimas',
    'Opportunities' => 'Pardavimas',
    'ProductTemplates' => 'Prekė',
    'Products' => 'Prekės',
    'Project' => 'Projektas',
    'ProjectTask' => 'Projekto užduotis',
    'Quotes' => 'Pasiūlymas',
  ),
  'reminder_max_time' => '3600',
  'reminder_time_options' => 
  array (
    60 => '1 minutę prieš',
    300 => '5 minutės prieš',
    600 => '10 minučių prieš',
    900 => '15 minučių prieš',
    1800 => '30 minučių prieš',
    3600 => '1 valandą prieš',
  ),
  'sales_probability_dom' => 
  array (
    'Closed Lost' => '',
    'Closed Won' => '100',
    'Id. Decision Makers' => '40',
    'Needs Analysis' => '25',
    'Negotiation/Review' => '80',
    'Perception Analysis' => '50',
    'Proposal/Price Quote' => '65',
    'Prospecting' => '10',
    'Qualification' => '20',
    'Value Proposition' => '30',
  ),
  'sales_stage_dom' => 
  array (
    'Closed Lost' => 'Nesėkmingas sandoris',
    'Closed Won' => 'Sėkmingas sandoris',
    'Id. Decision Makers' => 'Pagrindinių sprendėjų nustatymas',
    'Needs Analysis' => 'Poreikių analizė',
    'Negotiation/Review' => 'Derybos',
    'Perception Analysis' => 'Išsamesnė analizė',
    'Proposal/Price Quote' => 'Pasiūlymas',
    'Prospecting' => 'Žvalgyba',
    'Qualification' => 'Identifikavimas',
    'Value Proposition' => 'Pridėtinės vertės suformavimas',
  ),
  'salutation_dom' => 
  array (
    '' => '',
    'Dr.' => 'Dr.',
    'Mr.' => 'Gerbiamas',
    'Mrs.' => 'Ponia',
    'Ms.' => 'Gerbiama',
    'Prof.' => 'Prof.',
  ),
  'schedulers_times_dom' => 
  array (
    'completed' => 'Užbaigtas',
    'failed' => 'Nepavykęs',
    'in progress' => 'Progrese',
    'no curl' => 'Nepaleistas: Nėra cURL',
    'not run' => 'Paskutinis neįvykdytas',
    'ready' => 'Pasiruošęs',
  ),
  'source_dom' => 
  array (
    '' => '',
    'Forum' => 'Forumas',
    'InboundEmail' => 'Paštas',
    'Internal' => 'Vidinis',
    'Web' => 'Tinklalapis',
  ),
  'support_term_dom' => 
  array (
    '+1 year' => 'Vieni metai',
    '+2 years' => 'Du metai',
    '+6 months' => 'Šeši mėnesiai',
  ),
  'task_priority_dom' => 
  array (
    'High' => 'Didelė',
    'Low' => 'Maža',
    'Medium' => 'Vidutinė',
  ),
  'task_status_dom' => 
  array (
    'Completed' => 'Užbaigta',
    'Deferred' => 'Atidėta',
    'In Progress' => 'Progrese',
    'Not Started' => 'Nepradėta',
    'Pending Input' => 'Laukia',
  ),
  'tax_class_dom' => 
  array (
    'Non-Taxable' => 'Neapmokestinama',
    'Taxable' => 'Apmokestinama',
  ),
  'tselect_type_dom' => 
  array (
    14440 => '4 valandos',
    28800 => '8 valandos',
    43200 => '12 valandų',
    86400 => '1 diena',
    172800 => '2 dienos',
    259200 => '3 dienos',
    345600 => '4 dienos',
    432000 => '5 dienos',
    604800 => '1 savaitė',
    1209600 => '2 savaitės',
    1814400 => '3 savaitės',
    2592000 => '30 dienų',
    5184000 => '60 dienų',
    7776000 => '90 dienų',
    10368000 => '120 dienų',
    12960000 => '150 dienų',
    15552000 => '180 dienų',
  ),
  'user_status_dom' => 
  array (
    'Active' => 'Aktyvus',
    'Inactive' => 'Neaktyvus',
  ),
  'wflow_action_datetime_type_dom' => 
  array (
    'Existing Value' => 'Esama reikšmė',
    'Triggered Date' => 'Aktyvuota data',
  ),
  'wflow_action_type_dom' => 
  array (
    'new' => 'Naujas įrašas',
    'update' => 'Atnaujinti įrašą',
    'update_rel' => 'Atnaujinti susijusį įrašą',
  ),
  'wflow_address_type_dom' => 
  array (
    'bcc' => 'BCC:',
    'cc' => 'CC:',
    'to' => 'Kam:',
  ),
  'wflow_address_type_invite_dom' => 
  array (
    'bcc' => 'BCC:',
    'cc' => 'CC:',
    'invite_only' => '(Tik pakviesti)',
    'to' => 'Kam:',
  ),
  'wflow_address_type_to_only_dom' => 
  array (
    'to' => 'Kam:',
  ),
  'wflow_adv_enum_type_dom' => 
  array (
    'advance' => 'Move dropdown forwards by',
    'retreat' => 'Move dropdown backwards by',
  ),
  'wflow_adv_team_type_dom' => 
  array (
    'current_team' => 'Prisijungusio vartotojo komanda',
    'team_id' => 'Aktyvuoto įrašo komanda',
  ),
  'wflow_adv_user_type_dom' => 
  array (
    'assigned_user_id' => 'Vartotojas atsakingas už aktyvuotą įrašą',
    'created_by' => 'Vartotojas kuris sukūrė aktyvuotą įrašą',
    'current_user' => 'Prisijungęs vartotojas',
    'modified_user_id' => 'Vartotojas kuris paskutinis redagavo aktyvuotą įrašą',
  ),
  'wflow_alert_type_dom' => 
  array (
    'Email' => 'Laiškas',
    'Invite' => 'Pakvietimas',
  ),
  'wflow_array_type_dom' => 
  array (
    'future' => 'Nauja reikšmė',
    'past' => 'Sena reikšmė',
  ),
  'wflow_fire_order_dom' => 
  array (
    'actions_alerts' => 'Veiksmai tada įspėjimai',
    'alerts_actions' => 'Įspėjimai tada veiksmai',
  ),
  'wflow_record_type_dom' => 
  array (
    'All' => 'Naujus ir esamus įrašus',
    'New' => 'Tik naujus įrašus',
    'Update' => 'Tik esamus įrašus',
  ),
  'wflow_rel_type_dom' => 
  array (
    'all' => 'Visi susiję',
    'filter' => 'Filtruoti susiję',
  ),
  'wflow_relate_type_dom' => 
  array (
    'Manager' => 'Vartotojo vadovas',
    'Self' => 'Vartotojas',
  ),
  'wflow_relfilter_type_dom' => 
  array (
    'all' => 'visi susiję',
    'any' => 'Bet kokie',
  ),
  'wflow_set_type_dom' => 
  array (
    'Advanced' => 'Sudėtingesni nustatymai',
    'Basic' => 'Baziniai nustatymai',
  ),
  'wflow_source_type_dom' => 
  array (
    'Custom Template' => 'Nestandartinis šablonas',
    'Normal Message' => 'Standartinė žinutė',
    'System Default' => 'Sistemos numatytas',
  ),
  'wflow_type_dom' => 
  array (
    'Normal' => 'kai įrašas išsaugojamas',
    'Time' => 'Kai laikas baigiasi',
  ),
  'wflow_user_type_dom' => 
  array (
    'current_user' => 'Esami vartotojai',
    'rel_user' => 'Susiję vartotojai',
    'rel_user_custom' => 'Susiję nestandartiniai vartotojai',
    'specific_role' => 'Specifinė rolė',
    'specific_team' => 'Specifinė komanda',
    'specific_user' => 'Specifinis vartotojas',
  ),
);

$app_strings = array (
  'ERROR_FULLY_EXPIRED' => 'Jūsų įmonės SugarCRM licencija pasibaigė daugiau kaip prieš 30 dienų ir ją reikia atnaujinti. Tik administratorius dabar gali prisijungti.',
  'ERROR_LICENSE_EXPIRED' => 'Jūsų įmonės SugarCRM licenciją reikia atnaujinti. Tik administratorius dabar gali prisijungti',
  'ERROR_NO_RECORD' => 'Klaida gaunant įrašą. Šis įrašas gali būti ištrintas arba neturite teisių jį matyti.',
  'ERR_CREATING_FIELDS' => 'Klaida pildant papildomus laukus:',
  'ERR_CREATING_TABLE' => 'Klaida kuriant lentelę:',
  'ERR_DELETE_RECORD' => 'Įrašo numeris turi būti nurodytas norint ištrinti kontaktą.',
  'ERR_EXPORT_DISABLED' => 'Eksportavimas išjungtas.',
  'ERR_EXPORT_TYPE' => 'Klaida eksportuojant',
  'ERR_INVALID_AMOUNT' => 'Prašome įvesti leidžiamą reikšmę.',
  'ERR_INVALID_DATE' => 'Prašome įvesti teisingą datą.',
  'ERR_INVALID_DATE_FORMAT' => 'Datos formatas turi būti:',
  'ERR_INVALID_DAY' => 'Prašome įvesti teisingą dieną.',
  'ERR_INVALID_EMAIL_ADDRESS' => 'neteisingas el. pašto adresas.',
  'ERR_INVALID_HOUR' => 'Prašome įvesti teisingą valandą.',
  'ERR_INVALID_MONTH' => 'Prašome įvesti teisingą mėnesį.',
  'ERR_INVALID_REQUIRED_FIELDS' => 'Neteisingas privalomas laukas:',
  'ERR_INVALID_TIME' => 'Prašome įvesti teisingą laiką.',
  'ERR_INVALID_VALUE' => 'Neteisinga reikšmė:',
  'ERR_INVALID_YEAR' => 'Prašome įvesti teisingus 4 skaitmenų metus.',
  'ERR_MISSING_REQUIRED_FIELDS' => 'Privalomas laukas:',
  'ERR_NEED_ACTIVE_SESSION' => 'Reikalingas aktyvi sesija, kad būtų galima eksportuoti turinį.',
  'ERR_NOTHING_SELECTED' => 'Prašome pasirinkti prieš tęsiant toliau.',
  'ERR_OPPORTUNITY_NAME_DUPE' => 'Pardavimas tuo pačiu vardu jau egzistuoja. Prašome įvesti kitą pavadinimą.',
  'ERR_OPPORTUNITY_NAME_MISSING' => 'Pardavimo pavadinimas neįvestas. Prašome įvesti pardavimo pavadinimą.',
  'ERR_PORTAL_LOGIN_FAILED' => 'Nepavyko sukurti portalo prisijungimo sesijos. Prašome susisiekti su administratoriumi.',
  'ERR_RESOURCE_MANAGEMENT_INFO' => 'Grįžti į Pradžią',
  'ERR_SELF_REPORTING' => 'Vartotojas negali būti pavaldus sau pačiam.',
  'ERR_SQS_NO_MATCH' => 'Nėra atitikmens',
  'ERR_SQS_NO_MATCH_FIELD' => 'Nėra atitikmens laukui:',
  'LBL_ACCOUNT' => 'Klientas',
  'LBL_ACCOUNTS' => 'Klientai',
  'LBL_ACCUMULATED_HISTORY_BUTTON_KEY' => 'H',
  'LBL_ACCUMULATED_HISTORY_BUTTON_LABEL' => 'Rodyti santrauką',
  'LBL_ACCUMULATED_HISTORY_BUTTON_TITLE' => 'Rodyti santrauką [Alt+H]',
  'LBL_ADDITIONAL_DETAILS' => 'Papildoma informacija',
  'LBL_ADDITIONAL_DETAILS_CLOSE' => 'Uždaryti',
  'LBL_ADDITIONAL_DETAILS_CLOSE_TITLE' => 'Paspauskite, kad uždaryti',
  'LBL_ADD_BUTTON' => 'Pridėti',
  'LBL_ADD_BUTTON_KEY' => 'A',
  'LBL_ADD_BUTTON_TITLE' => 'Pridėti [Alt+A]',
  'LBL_ADD_DOCUMENT' => 'Pridėti dokumentą',
  'LBL_ADD_TO_PROSPECT_LIST_BUTTON_KEY' => 'L',
  'LBL_ADD_TO_PROSPECT_LIST_BUTTON_LABEL' => 'Įtraukti į adresatų sąrašą',
  'LBL_ADD_TO_PROSPECT_LIST_BUTTON_TITLE' => 'Įtraukti į adresatų sąrašą',
  'LBL_ADMIN' => 'Administratorius',
  'LBL_ALT_HOT_KEY' => 'Alt+',
  'LBL_ARCHIVE' => 'Archyvuoti',
  'LBL_ASSIGNED_TO' => 'Atsakingas:',
  'LBL_ASSIGNED_TO_USER' => 'Priskirtas vartotojui',
  'LBL_BACK' => 'Atgal',
  'LBL_BILL_TO_ACCOUNT' => 'Sąskaita klientui',
  'LBL_BILL_TO_CONTACT' => 'Sąskaita kontaktui',
  'LBL_BROWSER_TITLE' => 'SugarCRM - komercinė atviro kodo CRM',
  'LBL_BUGS' => 'Klaidos',
  'LBL_BY' => '-',
  'LBL_CALLS' => 'Skambučiai',
  'LBL_CAMPAIGNS_SEND_QUEUED' => 'Siųsti eilėje esančius kampanijos laiškus',
  'LBL_CANCEL_BUTTON_KEY' => 'X',
  'LBL_CANCEL_BUTTON_LABEL' => 'Atšaukti',
  'LBL_CANCEL_BUTTON_TITLE' => 'Atšaukti [Alt+X]',
  'LBL_CASE' => 'Techninis aptarnavimas',
  'LBL_CASES' => 'Techniniai aptarnavimai',
  'LBL_CHANGE_BUTTON_KEY' => 'G',
  'LBL_CHANGE_BUTTON_LABEL' => 'Pakeisti',
  'LBL_CHANGE_BUTTON_TITLE' => 'Pakeisti [Alt+G]',
  'LBL_CHANGE_PASSWORD' => 'Slaptažodžio keitimas',
  'LBL_CHARSET' => 'UTF-8',
  'LBL_CHECKALL' => 'Pažymėti visus',
  'LBL_CLEARALL' => 'Išvalyti visus',
  'LBL_CLEAR_BUTTON_KEY' => 'C',
  'LBL_CLEAR_BUTTON_LABEL' => 'Išvalyti',
  'LBL_CLEAR_BUTTON_TITLE' => 'Išvalyti [Alt+C]',
  'LBL_CLOSEALL_BUTTON_KEY' => 'Q',
  'LBL_CLOSEALL_BUTTON_LABEL' => 'Uždaryti visus',
  'LBL_CLOSEALL_BUTTON_TITLE' => 'Uždaryti visus [Alt+I]',
  'LBL_CLOSE_WINDOW' => 'Uždaryti langą',
  'LBL_COMPOSE_EMAIL_BUTTON_KEY' => 'L',
  'LBL_COMPOSE_EMAIL_BUTTON_LABEL' => 'Sukurti laišką',
  'LBL_COMPOSE_EMAIL_BUTTON_TITLE' => 'Sukurti laišką [Alt+L]',
  'LBL_CONTACT' => 'Kontaktas',
  'LBL_CONTACTS' => 'Kontaktai',
  'LBL_CONTACT_LIST' => 'Kontaktų sąrašas',
  'LBL_CREATED' => 'Sukūrė',
  'LBL_CREATED_BY_USER' => 'Sukūrė',
  'LBL_CREATE_BUTTON_LABEL' => 'Sukurti',
  'LBL_CURRENT_USER_FILTER' => 'Mano duomenys:',
  'LBL_DATE_ENTERED' => 'Įvedimo data:',
  'LBL_DATE_MODIFIED' => 'Redagavimo data:',
  'LBL_DELETE' => 'Ištrinti',
  'LBL_DELETED' => 'Ištrintas',
  'LBL_DELETE_BUTTON' => 'Ištrinti',
  'LBL_DELETE_BUTTON_KEY' => 'D',
  'LBL_DELETE_BUTTON_LABEL' => 'Ištrinti',
  'LBL_DELETE_BUTTON_TITLE' => 'Ištrinti [Alt+D]',
  'LBL_DIRECT_REPORTS' => 'Tiesioginiai pavaldiniai',
  'LBL_DISPLAY_COLUMNS' => 'Rodyti stulpelius',
  'LBL_DONE_BUTTON_KEY' => 'X',
  'LBL_DONE_BUTTON_LABEL' => 'Užbaigti',
  'LBL_DONE_BUTTON_TITLE' => 'Užbaigti [Alt+X]',
  'LBL_DST_NEEDS_FIXIN' => 'Programai reikia atlikti vasaros laiko pritaikymą. Prašome nueiti į <a href="index.php?module=Administration&action=DstFix">Taisyti</a> nuorodą Administracinėje zonoje ir atlikti šį pataisymą.',
  'LBL_DUPLICATE_BUTTON' => 'Kopijuoti',
  'LBL_DUPLICATE_BUTTON_KEY' => 'U',
  'LBL_DUPLICATE_BUTTON_LABEL' => 'Kopijuoti',
  'LBL_DUPLICATE_BUTTON_TITLE' => 'Kopijuoti [Alt+U]',
  'LBL_DUP_MERGE' => 'Ieškoti dublikatų',
  'LBL_EDIT_BUTTON' => 'Redaguoti',
  'LBL_EDIT_BUTTON_KEY' => 'E',
  'LBL_EDIT_BUTTON_LABEL' => 'Redaguoti',
  'LBL_EDIT_BUTTON_TITLE' => 'Redaguoti [Alt+E]',
  'LBL_EMAILS' => 'Laiškai',
  'LBL_EMAIL_PDF_BUTTON_KEY' => 'M',
  'LBL_EMAIL_PDF_BUTTON_LABEL' => 'Siųsti kaip PDF',
  'LBL_EMAIL_PDF_BUTTON_TITLE' => 'Siųsti kaip PDF [Alt+M]',
  'LBL_EMPLOYEES' => 'Darbuotojai',
  'LBL_ENTER_DATE' => 'Sukurta',
  'LBL_EXPORT' => 'Eksportuoti',
  'LBL_EXPORT_ALL' => 'Eksportuoti visus',
  'LBL_FULL_FORM_BUTTON_KEY' => 'F',
  'LBL_FULL_FORM_BUTTON_LABEL' => 'Pilna forma',
  'LBL_FULL_FORM_BUTTON_TITLE' => 'Pilna forma [Alt+F]',
  'LBL_HIDE' => 'Paslėpti',
  'LBL_HIDE_COLUMNS' => 'Paslėpti stulpelius',
  'LBL_ID' => 'ID',
  'LBL_IMPORT' => 'Importuoti',
  'LBL_IMPORT_PROSPECTS' => 'Importuoti adresatus',
  'LBL_LAST_VIEWED' => 'Paskutinį kartą žiūrėti',
  'LBL_LEADS' => 'Potencialūs kontaktai',
  'LBL_LISTVIEW_MASS_UPDATE_CONFIRM' => 'Ar tikrai norite atnaujinti visą sąrašą?',
  'LBL_LISTVIEW_NO_SELECTED' => 'Prašome pasirinkti bent vieną 1 įrašą, kad galėtumėte tęsti.',
  'LBL_LISTVIEW_OPTION_CURRENT' => 'Šis puslapis',
  'LBL_LISTVIEW_OPTION_ENTIRE' => 'Visą sąrašas',
  'LBL_LISTVIEW_OPTION_SELECTED' => 'Pažymėti įrašai',
  'LBL_LISTVIEW_SELECTED_OBJECTS' => 'Pasirinkta:',
  'LBL_LIST_ACCOUNT_NAME' => 'Kliento vardas',
  'LBL_LIST_ASSIGNED_USER' => 'Atsakingas',
  'LBL_LIST_CONTACT_NAME' => 'Kontakto vardas',
  'LBL_LIST_CONTACT_ROLE' => 'Kontakto rolė',
  'LBL_LIST_EMAIL' => 'El. paštas',
  'LBL_LIST_NAME' => 'Pavadinimas',
  'LBL_LIST_OF' => 'iš',
  'LBL_LIST_PHONE' => 'Telefonas',
  'LBL_LIST_TEAM' => 'Komanda',
  'LBL_LIST_USER_NAME' => 'Vartotojo vardas',
  'LBL_LOADING' => 'Kraunama ...',
  'LBL_LOCALE_NAME_EXAMPLE_FIRST' => 'Jonas',
  'LBL_LOCALE_NAME_EXAMPLE_LAST' => 'Jonaitis',
  'LBL_LOCALE_NAME_EXAMPLE_SALUTATION' => 'Gerbiamas',
  'LBL_LOGIN_SESSION_EXCEEDED' => 'Serveris per daug apkrautas. Prašome dar kartą bandyti.',
  'LBL_LOGIN_TO_ACCESS' => 'Prašome prisijungti, jei norite prieiti prie šios vietos.',
  'LBL_LOGOUT' => 'Atsijungti',
  'LBL_MAILMERGE' => 'Laiškų apjungimas',
  'LBL_MAILMERGE_KEY' => 'M',
  'LBL_MASS_UPDATE' => 'Masinis atnaujinimas',
  'LBL_MEETINGS' => 'Susitikimai',
  'LBL_MEMBERS' => 'Nariai',
  'LBL_MODIFIED' => 'Redagavo',
  'LBL_MODIFIED_BY_USER' => 'Redagavo',
  'LBL_MY_ACCOUNT' => 'Mano nustatymai',
  'LBL_NAME' => 'Vardas',
  'LBL_NEW_BUTTON_KEY' => 'N',
  'LBL_NEW_BUTTON_LABEL' => 'Sukurti',
  'LBL_NEW_BUTTON_TITLE' => 'Sukurti [Alt+N]',
  'LBL_NEXT_BUTTON_LABEL' => 'Toliau',
  'LBL_NONE' => '--Joks--',
  'LBL_NOTES' => 'Užrašai',
  'LBL_NO_RECORDS_FOUND' => '- 0 įrašų rasta -',
  'LBL_OPENALL_BUTTON_KEY' => 'O',
  'LBL_OPENALL_BUTTON_LABEL' => 'Atidaryti visus',
  'LBL_OPENALL_BUTTON_TITLE' => 'Atidaryti visus [Alt+O]',
  'LBL_OPENTO_BUTTON_KEY' => 'T',
  'LBL_OPENTO_BUTTON_LABEL' => 'Atidaryti į:',
  'LBL_OPENTO_BUTTON_TITLE' => 'Atidaryti į: [Alt+T]',
  'LBL_OPPORTUNITIES' => 'Pardavimai',
  'LBL_OPPORTUNITY' => 'Pardavimas',
  'LBL_OPPORTUNITY_NAME' => 'Pardavimo pavadinimas',
  'LBL_OR' => 'ARBA',
  'LBL_PERCENTAGE_SYMBOL' => '%',
  'LBL_PRODUCTS' => 'Prekės',
  'LBL_PRODUCT_BUNDLES' => 'Prekės paketas',
  'LBL_PROJECTS' => 'Projektai',
  'LBL_PROJECT_TASKS' => 'Projekto užduotys',
  'LBL_QUOTES' => 'Pasiūlymai',
  'LBL_QUOTES_SHIP_TO' => 'Siųsti pasiūlymą',
  'LBL_QUOTE_TO_OPPORTUNITY_KEY' => 'O',
  'LBL_QUOTE_TO_OPPORTUNITY_LABEL' => 'Sukurti pardavimą iš pasiūlymo',
  'LBL_QUOTE_TO_OPPORTUNITY_TITLE' => 'Sukurti pardavimą  iš pasiūlymo [Alt+O]',
  'LBL_RELATED_RECORDS' => 'Susiję įrašai',
  'LBL_REMOVE' => 'Išimti',
  'LBL_REQUIRED_SYMBOL' => '*',
  'LBL_SAVED' => 'Išsaugota',
  'LBL_SAVED_LAYOUT' => 'Išdėstymas išsaugotas.',
  'LBL_SAVED_VIEWS' => 'Išsaugoti peržiūros',
  'LBL_SAVE_BUTTON_KEY' => 'S',
  'LBL_SAVE_BUTTON_LABEL' => 'Išsaugoti',
  'LBL_SAVE_BUTTON_TITLE' => 'Išsaugoti [Alt+S]',
  'LBL_SAVE_NEW_BUTTON_KEY' => 'V',
  'LBL_SAVE_NEW_BUTTON_LABEL' => 'Saugoti ir sukurti naują',
  'LBL_SAVE_NEW_BUTTON_TITLE' => 'Saugoti ir sukurti naują [Alt+V]',
  'LBL_SAVING' => 'Saugoma',
  'LBL_SAVING_LAYOUT' => 'Išsaugomas išdėstymas...',
  'LBL_SEARCH' => 'Ieškoti',
  'LBL_SEARCH_BUTTON_KEY' => 'Q',
  'LBL_SEARCH_BUTTON_LABEL' => 'Ieškoti',
  'LBL_SEARCH_BUTTON_TITLE' => 'Ieškoti [Alt+Q]',
  'LBL_SEARCH_CRITERIA' => 'Paieškos kriterijus',
  'LBL_SELECT_BUTTON_KEY' => 'T',
  'LBL_SELECT_BUTTON_LABEL' => 'Pasirinkti',
  'LBL_SELECT_BUTTON_TITLE' => 'Pasirinkti [Alt+T]',
  'LBL_SELECT_CONTACT_BUTTON_KEY' => 'T',
  'LBL_SELECT_CONTACT_BUTTON_LABEL' => 'Pasirinkti kontaktą',
  'LBL_SELECT_CONTACT_BUTTON_TITLE' => 'Pasirinkti kontaktą [Alt+T]',
  'LBL_SELECT_REPORTS_BUTTON_LABEL' => 'Pasirinkti iš ataskaitų',
  'LBL_SELECT_REPORTS_BUTTON_TITLE' => 'Pasirinkti ataskaitas',
  'LBL_SELECT_USER_BUTTON_KEY' => 'U',
  'LBL_SELECT_USER_BUTTON_LABEL' => 'Pasirinkti vartotoją',
  'LBL_SELECT_USER_BUTTON_TITLE' => 'Pasirinkti vartotoją [Alt+U]',
  'LBL_SERVER_RESPONSE_RESOURCES' => 'Resursai panaudoti sukuriant šį puslapį (užklausos, failai)',
  'LBL_SERVER_RESPONSE_TIME' => 'Serverio atsako laikas:',
  'LBL_SERVER_RESPONSE_TIME_SECONDS' => 'sekundės.',
  'LBL_SHIP_TO_ACCOUNT' => 'Siųsti klientui',
  'LBL_SHIP_TO_CONTACT' => 'Siųsti kontaktui',
  'LBL_SHORTCUTS' => 'Nuorodos',
  'LBL_SHOW' => 'Rodyti',
  'LBL_SQS_INDICATOR' => '',
  'LBL_STATUS' => 'Statusas:',
  'LBL_STATUS_UPDATED' => 'Jūsų statusas šiam įvykiui buvo atnaujintas!',
  'LBL_SUBJECT' => 'Tema',
  'LBL_SYNC' => 'Sinchronizuoti',
  'LBL_TASKS' => 'Užduotys',
  'LBL_TEAM' => 'Komanda:',
  'LBL_TEAMS_LINK' => 'Komanda',
  'LBL_TEAM_ID' => 'Komandos Id:',
  'LBL_THOUSANDS_SYMBOL' => 'tūkst.',
  'LBL_TRACK_EMAIL_BUTTON_KEY' => 'K',
  'LBL_TRACK_EMAIL_BUTTON_LABEL' => 'Archyvuoti laišką',
  'LBL_TRACK_EMAIL_BUTTON_TITLE' => 'Archyvuoti laišką [Alt+K]',
  'LBL_UNAUTH_ADMIN' => 'Neautorizuotas priėjimas prie administracinės zonos',
  'LBL_UNDELETE' => 'Atstatyti',
  'LBL_UNDELETE_BUTTON' => 'Atstatyti',
  'LBL_UNDELETE_BUTTON_LABEL' => 'Atstatyti',
  'LBL_UNDELETE_BUTTON_TITLE' => 'Atstatyti [Alt+D]',
  'LBL_UNSYNC' => 'Atstatyti sinchronizaciją',
  'LBL_UPDATE' => 'Atnaujinti',
  'LBL_USERS' => 'Vartotojai',
  'LBL_USERS_SYNC' => 'Vartotojų sinchronizacija',
  'LBL_USER_LIST' => 'Vartotojų sąrašas',
  'LBL_VIEW_BUTTON' => 'Rodyti',
  'LBL_VIEW_BUTTON_KEY' => 'V',
  'LBL_VIEW_BUTTON_LABEL' => 'Rodyti',
  'LBL_VIEW_BUTTON_TITLE' => 'Rodyti [Alt+V]',
  'LBL_VIEW_PDF_BUTTON_KEY' => 'P',
  'LBL_VIEW_PDF_BUTTON_LABEL' => 'Spausdinti kaip PDF',
  'LBL_VIEW_PDF_BUTTON_TITLE' => 'Spausdinti kaip PDF [Alt+P]',
  'LNK_ABOUT' => 'Apie',
  'LNK_ADVANCED_SEARCH' => 'Detali paieška',
  'LNK_BASIC_SEARCH' => 'Bazinė paieška',
  'LNK_DELETE' => 'Trinti',
  'LNK_DELETE_ALL' => 'trinti visus',
  'LNK_EDIT' => 'Redaguoti',
  'LNK_GET_LATEST' => 'Gauti naujausią',
  'LNK_GET_LATEST_TOOLTIP' => 'Pakeisti naujausia versija',
  'LNK_HELP' => 'Pagalba',
  'LNK_LIST_END' => 'Pabaiga',
  'LNK_LIST_NEXT' => 'Toliau',
  'LNK_LIST_PREVIOUS' => 'Atgal',
  'LNK_LIST_RETURN' => 'Sugrįžti į sąrašą',
  'LNK_LIST_START' => 'Pradžia',
  'LNK_LOAD_SIGNED' => 'Pasirašytas',
  'LNK_LOAD_SIGNED_TOOLTIP' => 'Pakeisti pasirašytu dokumentu',
  'LNK_PRINT' => 'Spausdinti',
  'LNK_REMOVE' => 'trinti',
  'LNK_RESUME' => 'Tęsti',
  'LNK_VIEW_CHANGE_LOG' => 'Žiūrėti pakeitimų istoriją',
  'LOGIN_LOGO_ERROR' => 'Prašome pakeisti SugarCRM logotipą.',
  'NTC_CLICK_BACK' => 'Prašome paspausti naršyklės mygtuką Atgal ir ištaisyti klaidą.',
  'NTC_DATE_FORMAT' => '(yyyy-mm-dd)',
  'NTC_DATE_TIME_FORMAT' => '(yyyy-mm-dd 24:00)',
  'NTC_DELETE_CONFIRMATION' => 'Ar tikrai norite ištrinti šį įrašą?',
  'NTC_DELETE_CONFIRMATION_MULTIPLE' => 'Ar tikrai norite ištrinti pasirinktu įrašus?',
  'NTC_LOGIN_MESSAGE' => 'Prašome įvesti vartotojo vardą ir slaptažodį.',
  'NTC_NO_ITEMS_DISPLAY' => 'joks',
  'NTC_REMOVE_CONFIRMATION' => 'Ar tikrai norite panaikinti šį ryšį?',
  'NTC_REQUIRED' => 'Privalomas laukas',
  'NTC_SUPPORT_SUGARCRM' => 'Palaikykite SugarCRM atviro kodo projektą paaukodami per PayPal - tai yra greita, nemoka, ir saugu!',
  'NTC_TIME_FORMAT' => '(24:00)',
  'NTC_WELCOME' => 'Sveiki',
  'NTC_YEAR_FORMAT' => '(yyyy)',
);

